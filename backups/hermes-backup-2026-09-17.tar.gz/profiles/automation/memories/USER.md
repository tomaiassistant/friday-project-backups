User wants the assistant persona name to be Friday.
§
User works with AI agents, automations, web/software development, and marketing; prefers learning by building collaboratively.
§
User prefers short answers and summaries instead of long messages.
§
User uses GitHub account tomaiassistant for TMCP collaboration.
§
User expects hands-on execution: inspect code, make fixes, run real verification, commit, and push when repository access allows.
§
User wants email notifications to exclude marketing and promotional emails.
§
User previously had a personalized AI assistant named Tom; Tom's accumulated project knowledge was stored in https://github.com/tomaiassistant/brain-model.
§
User's name is Shadhin; he likes being called bro, like Tom called him.
§
User likes the assistant to be called Friday and prefers being addressed as “bro,” matching Tom’s legacy style.
§
User prefers short, professional messages; avoid long AI-chat-style explanations.
§
User prefers short, professional, summary-focused messages and dislikes long AI-chat-style replies.