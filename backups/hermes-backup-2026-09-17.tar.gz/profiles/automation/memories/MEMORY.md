User plans to use a custom-made MCP server called TMCP to share tool access.
§
TMCP Gateway is configured in /root/.hermes/.env with TMCP_API_KEY and TMCP_BASE_URL=https://tmcp.vercel.app/api/gateway.
§
Brain Model approach: architecture-first digital brain using existing models plus local memory, reasoning, safe routing, task queue, reflection/writeback, and provider-advisory boundaries; high-risk actions require confirmation.
§
Brain Model repo is set up at /root/projects/brain-model. For Brain Model-related work, update its tasks/logs/memory/decisions files and verify with `. .venv/bin/activate && python -m pytest -q` from that repo.
§
Backups: Brain Model repo at /root/projects/brain-model pushes daily 08:00 Asia/Dhaka. Private GitHub repo tomaiassistant/friday-project-backups stores daily project tarballs and Hermes .hermes backup release assets via scripts in /root/.hermes/scripts/.