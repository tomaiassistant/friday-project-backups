User wants the assistant persona name to be Friday.
§
User uses GitHub account tomaiassistant for TMCP collaboration.
§
User's name is Shadhin; he likes being called bro, like Tom called him.
§
User prefers to call the assistant Friday and be addressed as bro.
§
User wants immediate execution with real data, concise 2‑3 line replies, Google Drive backups, proactive context and continuity; prefers direct GitHub/SSH authentication.
§
ListingsFinder: integrate into Hermes as skill/MCP toolset via TMCP gateway (not standalone app).
§
User prefers direct GitHub account or SSH key authentication over token-based access when possible.
§
User values continuity; gets frustrated when prior decisions/instructions are rolled back—respect context and avoid repeating old suggestions as new.
§
Crisis tasks (blocked automation): detect hard blocker immediately, state fix needed plainly, skip test cycles. User hates excuses.
§
Uses context proactively; frustrated when agent forgets
§
Switched to Nemotron 120B after Gemma 4 31B crushed Hermes 3x
§
Prefers Google Drive for Hermes backups over GitHub
§
Wants summary/parsed info; emails: prefer sender/subject
§
User wants to be called 'bro' and wants assistant to be called 'Friday'