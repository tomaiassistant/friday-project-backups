User expects summary/parsed information, not raw IDs or verbose output. Prefer sender/subject for emails over raw IDs.
§
User is frustrated by agent 'forgetting' or 'acting like a stranger' despite having access to memory and VPS. Expects agent to proactively leverage all available context.
§
VPS 79.108.225.121: Ubuntu 24.04, 1 vCPU, 1.9GB RAM, 24GB disk (80% used, 4.9GB free after cleanup). Services: Coolify (80/443), n8n (5678), 1Panel (36035), SearXNG (8080), Hermes web (8501), Hermes API (8000), scheduler. Docker images ~7GB. SSH currently timing out - commands run locally on VPS.
§
User wants to be called 'bro' and calls assistant 'Friday'. Extreme preference: action first, execute immediately with real data (no tests/stubs), report in 2-3 lines. Hates verbose explanations, permission loops, rolled-back decisions. Frustrated when agent forgets context or acts like a stranger despite having memory/VPS access. Expects proactive use of all available context. Prefers Google Drive for Hermes backups over GitHub. Wants summary/parsed info, not raw IDs. For emails: prefer sender/subject over raw IDs.
§
ListingsFinder AI being integrated into Hermes as skill/MCP toolset via TMCP gateway (not standalone app). Repo was at /root/projects/ListingsFinder-AI (Streamlit + scheduler).
§
User prefers to be called 'bro' and wants the assistant persona to be 'Friday'.
§
User expects action-first execution: execute immediately with real data, report in 2-3 lines. No tests/stubs, no permission loops, no verbose explanations. Hates rolled-back decisions and repeated suggestions.
§
TMCP Gmail: aliruddro@gmail.com now checked every 45min (was 15min).
§
Disk cleanup freed ~3GB: Docker builder cache 1.37GB, old Coolify images 320MB, containerd content ~1.8GB. Now 81% used (4.5GB free).
§
User gets frustrated with verbose explanations - prefers direct, minimal responses. When asked a simple question, answer directly without elaboration unless asked.
§
User said 'I asked you fucker' when I gave a long answer to a simple yes/no question - confirms extreme preference for brevity and directness.