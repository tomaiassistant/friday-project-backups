#!/usr/bin/env bash
set -euo pipefail

REPO="/root/projects/brain-model"
ASKPASS="/root/.hermes/scripts/github-askpass-friday.sh"

# Skip if repo is missing.
[ -d "$REPO/.git" ] || exit 0

cd "$REPO"

# Commit any pending Brain Model updates.
if ! git diff --quiet || [ -n "$(git ls-files --others --exclude-standard)" ]; then
  git add -A
  git commit -m "chore: daily Brain Model backup $(date -u +%F)" >/dev/null
fi

# Push current branch.
GIT_ASKPASS="$ASKPASS" GIT_TERMINAL_PROMPT=0 git push origin HEAD:main

echo "Brain Model daily backup pushed at $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
