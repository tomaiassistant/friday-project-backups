#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
PYTHON_BIN="${PYTHON_BIN:-python3}"
PORT="${PORT:-8501}"

cd "$ROOT_DIR"

if [ ! -d .venv ]; then
  "$PYTHON_BIN" -m venv .venv
fi

# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt

mkdir -p data exports credentials

if [ ! -f .env ] && [ -f .env.example ]; then
  cp .env.example .env
fi

echo "Bootstrap complete."
echo "Next:"
echo "  source .venv/bin/activate"
echo "  streamlit run app.py --server.port $PORT --server.address 0.0.0.0"
echo "  python -m listingsfinder.scheduler"
