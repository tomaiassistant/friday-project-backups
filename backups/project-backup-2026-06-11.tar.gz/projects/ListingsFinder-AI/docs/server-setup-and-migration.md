# ListingsFinder AI — server setup and later migration

This project is meant to run *alongside* the existing Hermes installation and other applications without interfering with them.

## Recommended deployment shape

- Keep `ListingsFinder-AI` in its own directory.
- Use its own Python virtual environment.
- Run the Streamlit app on its own port, normally `8501`.
- Run scheduled mandates with a separate process or cron job.
- Keep Hermes as the host automation layer; do not move Hermes or this app into the same venv.

This avoids conflicts with:
- Hermes CLI / gateway
- other Python apps
- system packages
- different API keys and credentials

## On the current server

Use this layout:

```text
/opt/apps/ListingsFinder-AI/
  .venv/
  data/
  exports/
  credentials/
  .env
  app.py
  listingsfinder/
```

### One-time install

```bash
cd /opt/apps/ListingsFinder-AI
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

### Run the UI

```bash
source .venv/bin/activate
streamlit run app.py --server.port 8501 --server.address 0.0.0.0
```

### Run scheduled mandates

```bash
source .venv/bin/activate
python -m listingsfinder.scheduler
```

## Production service recommendation

If you want it always-on, use **systemd** or a supervisor instead of keeping the UI in a terminal.

Suggested services:
- `listingsfinder-ui.service` → Streamlit app
- `listingsfinder-scheduler.service` → scheduled mandate worker

## Environment separation

Keep project secrets inside the project only:

- `.env`
- `credentials/service_account.json`
- `credentials/oauth_token.json`

Do **not** reuse Hermes secrets for the app unless the value is intentionally shared.

## How to migrate later to the client VPS

The migration should be simple if we keep the same structure:

1. Push the repo to GitHub.
2. On the client VPS, clone the same repo.
3. Create the same `.venv` and install the same requirements.
4. Copy or re-create:
   - `.env`
   - Google service account JSON
   - Google OAuth token JSON if used
   - any local `data/` or `exports/` files you want to keep
5. Update the Google Sheet / Resend / search credentials for the new server if needed.
6. Start the same Streamlit and scheduler commands.

### What makes migration easy

- No hardcoded machine paths.
- Same repo, same commands.
- App state lives in `data/` and `exports/`.
- Secrets live in the project environment, not in code.

## Why this won’t break Hermes

Hermes can keep running normally because this setup uses:
- separate process
- separate port
- separate virtual environment
- separate project folder

So the app can be added now without disturbing the current Hermes installation.
