import json
import os
from functools import lru_cache
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen


def _load_env() -> None:
    # Prefer the active environment; fall back to ~/.hermes/.env for Hermes runs.
    hermes_env = Path.home() / ".hermes" / ".env"
    if hermes_env.exists():
        for raw in hermes_env.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip())


@lru_cache(maxsize=1)
def _tmcp_config() -> tuple[str, str] | None:
    _load_env()
    base = (os.getenv("TMCP_BASE_URL") or "").strip().rstrip("/")
    key = (os.getenv("TMCP_API_KEY") or "").strip()
    if not base or not key:
        return None
    return base, key


@lru_cache(maxsize=1)
def _tmcp_tools() -> dict[str, dict[str, Any]]:
    cfg = _tmcp_config()
    if not cfg:
        return {}
    base, key = cfg
    req = Request(
        base + "/tools",
        headers={"Authorization": f"Bearer {key}", "Accept": "application/json"},
    )
    with urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read().decode("utf-8", "replace"))
    tools = {}
    for item in data.get("tools", []) or []:
        slug = item.get("slug")
        if slug:
            tools[slug] = item
    return tools


def tmcp_execute(tool: str, action: str, input_data: dict[str, Any]) -> dict[str, Any] | None:
    cfg = _tmcp_config()
    if not cfg:
        return None
    tools = _tmcp_tools()
    item = tools.get(tool)
    if not item:
        return None
    payload = {
        "tool": tool,
        "action": action,
        "input": input_data,
        "account_id": item.get("tool_account_id"),
    }
    base, key = cfg
    req = Request(
        base + "/execute",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    with urlopen(req, timeout=120) as resp:
        return json.loads(resp.read().decode("utf-8", "replace"))
