import re, hashlib, requests
from urllib.parse import urljoin, urlparse, quote_plus
from bs4 import BeautifulSoup
from .config import SCRAPEDO_TOKEN
from .models import Listing, now_iso
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125 Safari/537.36'
def fetch_url(url):
    try:
        r=requests.get(url,headers={'User-Agent':UA},timeout=20)
        if r.status_code<400 and len(r.text)>200: return r.text,'direct'
    except Exception: pass
    if SCRAPEDO_TOKEN:
        try:
            r=requests.get(f'https://api.scrape.do?token={SCRAPEDO_TOKEN}&url={quote_plus(url)}&render=false',timeout=45)
            if r.status_code<400: return r.text,'scrape.do'
        except Exception:
            pass
    return '','failed'
def first(text, pats):
    for p in pats:
        m=re.search(p,text or '',re.I)
        if m: return m.group(0)[:150]
    return ''

SALE_TERMS = (
    "for sale",
    "business for sale",
    "company for sale",
    "business opportunity",
    "acquisition opportunity",
    "asking price",
    "view details",
    "more details",
    "listing",
    "listings",
)

DIRECTORY_TERMS = (
    "/search/",
    "/browse",
    "/marketplace",
    "/listings/",
    "/result",
    "category",
    "directory",
    "browse ",
    "search ",
    "commercial listings",
    "buy & sell",
    "currently available",
)

NON_LISTING_TERMS = (
    "job",
    "jobs",
    "career",
    "careers",
    "linkedin.com/company",
    "college of",
    "ocpinfo.com",
    "canlii.org",
    "reddit.com",
    "linkedin.com",
    "facebook.com/groups",
    "franchise opportunities",
)


def title_from_url(url):
    slug = urlparse(url).path.rstrip("/").split("/")[-1]
    slug = re.sub(r"\.(aspx|html?|php)$", "", slug, flags=re.I)
    return re.sub(r"[-_]+", " ", slug).strip().title()


def _clean_title(value):
    value = re.sub(r"\s+", " ", (value or "")).strip()
    value = re.sub(r"\s*\|\s*.*$", "", value)
    value = re.sub(r"\s*[\-–—]\s*(?:business(?:es)? for sale.*|for sale.*|listings?.*|marketplace.*|buy a business.*)$", "", value, flags=re.I)
    value = re.sub(r"\s*[\-–—]\s*(?:brokerage|broker|franchise).*$", "", value, flags=re.I)
    value = re.sub(r"\s+", " ", value).strip(" -–—|,.")
    return value


def _is_generic_title(value):
    low = (value or "").lower()
    generic_terms = (
        "businesses for sale",
        "business for sale",
        "for sale",
        "view details",
        "more details",
        "search results",
        "marketplace",
        "buy a business",
        "listings",
        "listing",
    )
    return not low or any(term in low for term in generic_terms)


def _best_title(result, soup):
    candidates = []
    for selector in ("h1", "meta[property='og:title']", "meta[name='title']", "title"):
        try:
            nodes = soup.select(selector) if selector == "h1" else soup.select(selector)
        except Exception:
            nodes = []
        for node in nodes[:3]:
            if selector.startswith("meta"):
                candidates.append(node.get("content", ""))
            else:
                candidates.append(node.get_text(" ", strip=True))
    candidates.append(result.get("title", ""))
    candidates.append(title_from_url(result.get("url", "")))
    for candidate in candidates:
        cleaned = _clean_title(candidate)
        if cleaned and not _is_generic_title(cleaned):
            return cleaned[:300]
    fallback = _clean_title(result.get("title", "")) or title_from_url(result.get("url", ""))
    return fallback[:300]


def _price_number(text):
    raw = (text or "").strip()
    if not raw:
        return "", ""
    currency = ""
    if re.search(r"\b(CAD|CA\$|C\$)\b", raw, re.I):
        currency = "CAD"
    elif re.search(r"\b(USD|US\$|U\$S)\b", raw, re.I):
        currency = "USD"
    elif "$" in raw:
        currency = "CAD"
    matches = list(re.finditer(r"(?P<symbol>CA\$|C\$|US\$|U\$S|\$)?\s*(?P<num>[0-9][0-9,]*(?:\.[0-9]+)?)\s*(?P<unit>MM|M|K|million|thousand)?", raw, re.I))
    if not matches:
        return "", f"price_text={raw}" if raw else ""
    first = matches[0]
    num = float(first.group("num").replace(",", ""))
    unit = (first.group("unit") or "").lower()
    if unit in ("m", "mm", "million"):
        num *= 1_000_000
    elif unit in ("k", "thousand"):
        num *= 1_000
    value = str(int(round(num))) if num.is_integer() else str(num)
    note_parts = []
    if currency:
        note_parts.append(f"currency={currency}")
    if len(matches) > 1 or any(ch in raw for ch in ("-", "to", "through")):
        note_parts.append(f"range={raw}")
    elif raw:
        note_parts.append(f"price_text={raw}")
    return value, "; ".join(note_parts)



def _industry_tokens(industry):
    return {w for w in re.split(r"[^a-z0-9]+", (industry or "").lower()) if len(w) > 2}


def _location_tokens(location):
    normalized = re.sub(r"\s+", " ", (location or "").strip().lower())
    tokens = {w for w in re.split(r"[^a-z0-9]+", normalized) if len(w) > 2}
    aliases = {
        "alabama": "al", "alaska": "ak", "arizona": "az", "arkansas": "ar", "california": "ca",
        "colorado": "co", "connecticut": "ct", "delaware": "de", "florida": "fl", "georgia": "ga",
        "hawaii": "hi", "idaho": "id", "illinois": "il", "indiana": "in", "iowa": "ia",
        "kansas": "ks", "kentucky": "ky", "louisiana": "la", "maine": "me", "maryland": "md",
        "massachusetts": "ma", "michigan": "mi", "minnesota": "mn", "mississippi": "ms",
        "missouri": "mo", "montana": "mt", "nebraska": "ne", "nevada": "nv", "hampshire": "nh",
        "ohio": "oh", "oklahoma": "ok", "oregon": "or", "pennsylvania": "pa", "rhode": "ri",
        "tennessee": "tn", "texas": "tx", "utah": "ut", "vermont": "vt", "virginia": "va",
        "washington": "wa", "wisconsin": "wi", "wyoming": "wy",
        "ontario": "on", "quebec": "qc", "alberta": "ab", "manitoba": "mb",
        "saskatchewan": "sk",
        "new york": "ny", "new jersey": "nj", "new mexico": "nm", "north carolina": "nc",
        "south carolina": "sc", "north dakota": "nd", "south dakota": "sd", "new hampshire": "nh",
        "rhode island": "ri", "west virginia": "wv", "british columbia": "bc", "nova scotia": "ns",
        "new brunswick": "nb", "newfoundland": "nl", "newfoundland and labrador": "nl",
        "prince edward island": "pe",
    }
    for name, alias in aliases.items():
        if name == normalized or name in normalized:
            tokens.add(alias)
    return tokens


def is_directory_result(result):
    haystack = " ".join([result.get("title", ""), result.get("url", ""), result.get("snippet", "")]).lower()
    url_path = urlparse(result.get("url", "")).path.lower()
    title = (result.get("title", "") or "").lower()
    if re.search(r"\b[a-z0-9 &'-]+s\s+for sale(?:\s+in\b|$)", title):
        return True
    if url_path.rstrip("/") in ("/commercial", "/business-for-sale", "/marketplace"):
        return True
    if url_path in ("", "/") and any(term in haystack for term in ("marketplace", "buy & sell", "for sale canada")):
        return True
    return any(term in haystack for term in DIRECTORY_TERMS)


def is_relevant_result(result, industry="", location=""):
    haystack = " ".join([result.get("title", ""), result.get("url", ""), result.get("snippet", "")]).lower()
    title = (result.get("title", "") or "").strip().lower()
    if title in ("skip to content", "more details", "view details", "contact seller", "save"):
        return False
    industry_words = _industry_tokens(industry)
    title_url = " ".join([result.get("title", ""), result.get("url", "")]).lower()
    if industry_words and not any(word in title_url or word in haystack for word in industry_words):
        return False
    has_industry = not industry_words or any(word in haystack for word in industry_words)
    location_words = _location_tokens(location)
    has_location = not location_words or any(word in haystack for word in location_words)
    if not has_location:
        return False
    has_sale = any(term in haystack for term in SALE_TERMS) or bool(re.search(r"\$[0-9][0-9,.]+", haystack))
    if any(term in haystack for term in ("linkedin.com", "facebook.com/groups")):
        return False
    if any(term in haystack for term in NON_LISTING_TERMS) and not ("for sale" in haystack and re.search(r"\$[0-9]|asking price|cash flow|revenue", haystack)):
        return False
    return bool(has_industry and has_sale)


def discover_listing_links(result, industry="", location="", max_links=12):
    html, method = fetch_url(result.get("url", ""))
    if not html:
        return []
    soup = BeautifulSoup(html, "lxml")
    base_url = result.get("url", "")
    base_domain = urlparse(base_url).netloc.replace("www.", "")
    found = []
    seen = set()
    for anchor in soup.find_all("a", href=True):
        href = urljoin(base_url, anchor["href"])
        parsed = urlparse(href)
        domain = parsed.netloc.replace("www.", "")
        if domain != base_domain:
            continue
        if parsed.path in ("", "/"):
            continue
        clean_url = href.split("#")[0]
        if clean_url in seen:
            continue
        text = " ".join(anchor.get_text(" ", strip=True).split())
        if len(text) < 4:
            continue
        parent_text = " ".join((anchor.parent.get_text(" ", strip=True) if anchor.parent else text).split())
        candidate = {
            "title": title_from_url(clean_url) if text.lower().startswith("more detail") else (text or result.get("title", "")),
            "url": clean_url,
            "snippet": parent_text[:500] or result.get("snippet", ""),
            "source": f"{result.get('source', 'Google/Serper')} expanded",
            "query": result.get("query", ""),
        }
        path = parsed.path.lower()
        if any(skip in path for skip in ("/contact", "/login", "/sign", "shortlist", "alert", "save=")):
            continue
        if is_directory_result(candidate) and "/search/" in path:
            continue
        if is_relevant_result(candidate, industry, location):
            seen.add(clean_url)
            found.append(candidate)
            if len(found) >= max_links:
                break
    return found


def expand_directory_results(results, industry="", location="", max_links_per_page=12):
    expanded = []
    seen = set()
    for result in results:
        is_directory = is_directory_result(result)
        children = discover_listing_links(result, industry, location, max_links=max_links_per_page) if is_directory else []
        candidates = children if children else ([] if is_directory else [result])
        for candidate in candidates:
            url = candidate.get("url", "")
            if url and url not in seen and is_relevant_result(candidate, industry, location):
                seen.add(url)
                expanded.append(candidate)
    return expanded


def scrape_result(result, industry='', location=''):
    html, method = fetch_url(result['url'])
    soup = BeautifulSoup(html or '', 'lxml')
    title = _best_title(result, soup)
    meta = soup.find('meta', attrs={'name': 'description'}) or soup.find('meta', attrs={'property': 'og:description'})
    desc = (meta.get('content', '') if meta else '') or result.get('snippet', '')
    text = soup.get_text(' ', strip=True)[:8000]
    if not desc:
        desc = text[:500]
    url = result['url']
    domain = urlparse(url).netloc.replace('www.', '')
    lid = hashlib.sha1(url.encode()).hexdigest()[:12].upper()
    asking_price_raw = first(text, [r'(?:asking price|price)[:\s]*\$[0-9,]+(?:\.?[0-9]+)?\s*(?:M|K|million)?', r'\$[0-9][0-9,]+(?:\.?[0-9]+)?\s*(?:M|K|million)?'])
    asking_price, price_note = _price_number(asking_price_raw)
    notes_parts = [f'fetch_method={method}', f'query={result.get("query", "")}']
    if price_note:
        notes_parts.append(price_note)
    if location and 'canada' in location.lower() and 'currency=CAD' not in '; '.join(notes_parts):
        notes_parts.append('currency=CAD')
    l = Listing(
        listing_id=f'SRC-{lid}',
        source=domain,
        source_url=url,
        listing_title=title,
        industry=industry,
        location=location,
        asking_price=asking_price,
        revenue=first(text, [r'(?:revenue|sales)[:\s]*\$[0-9,]+(?:\.?[0-9]+)?\s*(?:M|K|million)?']),
        cash_flow=first(text, [r'(?:cash flow|sde)[:\s]*\$[0-9,]+(?:\.?[0-9]+)?\s*(?:M|K|million)?']),
        ebitda=first(text, [r'EBITDA[:\s]*\$[0-9,]+(?:\.?[0-9]+)?\s*(?:M|K|million)?']),
        description=desc[:1000],
        contact_email=first(text, [r'[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}']),
        contact_phone=first(text, [r'(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}']),
        scrape_date=now_iso(),
        notes='; '.join(notes_parts),
    )
    return l
