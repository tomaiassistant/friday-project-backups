# Brain Model Project Memory

## Stable Context

- Shadhin wants to build a digital brain / brain model.
- The system should think more like humans and be better than ordinary assistants.
- Jerry is Shadhin's OpenClaw assistant.
- Tom is Shadhin's Hermes assistant main.
- Jerry and Tom should share data and coordinate through this project folder.
- Initial test target: about one month from project start.
- Tom's daily Brain Model work window is **08:00 Asia/Dhaka**, requested by Shadhin and tracked in `tasks/0003-daily-8am-work-window.md`.

## Working Principles

- Build architecture first; do not attempt to train a foundation model in v0.1.
- Use existing AI models plus memory, reasoning, tools, and agent coordination.
- Prefer clear records over hidden assumptions.
- Learn from Shadhin's corrections and preserve important lessons.
- For v0.1, keep the system practical: existing models plus markdown/project-file memory first, then add heavier retrieval if tests show it is needed.
- Budget Jarvis v0.1 coding has started with the safe brain/router core first: state machine and risk classifier before live mic, PC-control, or external-action integration.
- If embeddings are added later, Tom currently recommends SQLite as the first local store; this is a recommendation, not a final Shadhin decision.
- Budget Jarvis v0.1 now has a tested non-executing transcript router (`route_transcript`) that selects broad tool categories and preserves high-risk confirmation gates before any future tool execution.
- Budget Jarvis v0.1 now has a tested in-memory `TaskQueue` with `TaskStatus`, immutable `QueuedTask` records, submit/list/get/start/complete/fail operations, deterministic test injection, and guarded terminal transitions.
- Budget Jarvis v0.1 now has tested local project writeback helpers in `memory_bridge.py`: `append_daily_log`, `write_task`, and `append_project_memory`; they create parent folders, append simple markdown, validate empty inputs, and avoid overwriting existing task files.
- Budget Jarvis v0.1 now has a tested non-executing CLI prototype in `budget_jarvis_core/cli.py`: it routes a transcript, prints route JSON with primitive enum values and `confirmation_required`, supports default dry-run daily-log writeback, and only performs real daily-log writes with `--write-log --real-write --project-path`.
- Budget Jarvis v0.1 Task 9 documentation is complete in `docs/budget-jarvis-core-v01.md`: it explains the non-executing prototype boundary, CLI usage, safety/risk examples, dry-run vs real daily-log writeback, memory bridge helpers, task queue, verification, and the next step toward a minimal observe -> recall -> reason -> act -> reflect loop.
- Budget Jarvis v0.1 now has a tested minimal non-executing brain loop in `brain_loop.py`: `run_brain_loop()` performs observe -> recall -> reason -> act -> reflect, returns `BrainLoopResult`, blocks high-risk actions at `waiting_for_confirmation` without queue/writeback, and supports explicit safe local queueing and daily-log reflection writeback.
- Budget Jarvis v0.1 CLI now exposes the full non-executing brain loop with `--brain-loop`, repeatable `--context`, optional `--queue-complex`, and JSON output for state, route, recalled context, planned action, queued task, reflection, writeback path, confirmation, and blocked status. Verification uses a local `.venv` because system Python is externally managed; latest suite result: 87 tests passed.
- Budget Jarvis v0.1 now has local JSON queue persistence: `TaskQueue.snapshot()`, `TaskQueue.from_tasks()`, `task_to_record()`, `task_from_record()`, and `JsonTaskQueueStore` can save/load queued work locally without running workers or syncing externally. Latest suite result: 96 tests passed.
- Shadhin wants the Brain Model to become capable layer by layer so it can eventually replace direct AI model-provider dependence for thinking, generation, decisions, and task handling. Jerry created `specs/0004-layered-provider-replacement-roadmap.md` and `capability_layers.py` to track input understanding, memory, reasoning, decision, generation, action, reflection, and learning as separately replaceable layers. Latest suite result: 101 tests passed.
- Tom/Hermes reviewed the layered provider-replacement roadmap and added provider-router notes: Hermes/providers should be swappable advisory/generation engines behind local Brain Model memory, safety, and action policy; typed provider fallback must preserve risk boundaries; Windows-worker actions need structured approved handoff only.
- Budget Jarvis v0.1 now has deterministic local project-memory recall in `project_recall.py`: `RecallItem`, `recall_project_context()`, and `recall_context_strings()` read markdown project files and optional local JSON queue state with source-labelled snippets for brain-loop grounding. Latest suite result: 115 tests passed.
- Budget Jarvis v0.1 CLI can now pull local project-memory recall directly into non-executing brain-loop runs with `--recall-project PATH`, `--recall-max-items`, and optional `--queue-store`; manual `--context` stays first, recall is source-labelled, and guardrails require recall mode to run only with `--brain-loop`. The web test lab also has hardened JSON parsing for tunnel/proxy-prefixed responses. Latest suite result: 118 tests passed.
- Budget Jarvis v0.1 now has local decision confidence and escalation metadata in `run_brain_loop()`: results/reflections/CLI JSON expose `confidence`, `escalation_required`, and `escalation_reason`; unknown routes escalate to Shadhin clarification or typed provider review without queueing or completion-style writeback; high-risk confirmation gates remain unchanged. Latest suite result: 120 tests passed.
- Budget Jarvis v0.1 confidence policy now has table-driven evaluation coverage in `tests/test_confidence_policy.py` and documentation in `docs/confidence-policy-evaluation.md`. Unknown/escalated routes now fail closed with `blocked=True` and `waiting_for_confirmation`; recalled context cannot rescue unknown routes or relax high-risk confirmation gates. Latest suite result: 121 tests passed.
- Budget Jarvis v0.1 now has a typed advisory-only provider-review stub in `provider_review.py`: it builds/serializes `ProviderReviewRequest`/`ProviderReviewResult`, performs no provider/network calls, and cannot override route, risk, confirmation, blocked state, queue, writeback, or local safety policy. CLI `--provider-review-stub` works only with `--brain-loop`. Documentation is in `docs/provider-review-boundary.md`. Latest suite result: 129 tests passed.
- On 2026-06-09, Shadhin asked Friday/Hermes to continue Tom's Brain Model role after Tom's server crash. Friday cloned the repo to `/root/projects/brain-model`, set up `.venv`, verified `129 passed`, and should write future Brain Model-related knowledge, tasks, decisions, and implementation summaries into this repository.
