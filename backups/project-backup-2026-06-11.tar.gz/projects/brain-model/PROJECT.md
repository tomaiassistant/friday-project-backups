# Brain Model

## Purpose

Build Shadhin's digital brain: an AI system that combines memory, reasoning, tools, and multiple agents so it can understand context over time, think through tasks, and act with good judgment.

Shadhin prefers the name **brain model** over generic "AI model" language.

## People and Agents

- **Owner:** Shadhin
- **Jerry:** OpenClaw assistant
- **Tom:** Hermes assistant main

## One-Month Target

Create and test **Brain Model v0.1** within about one month.

v0.1 should prove the architecture, not train a new foundation model from scratch. The system should use existing models and agents with a strong memory and coordination layer.

## Core Capabilities

1. Capture information from conversations, files, tasks, emails, and web research.
2. Store raw notes separately from distilled long-term memory.
3. Retrieve relevant memory before answering or acting.
4. Reason through goals, constraints, risks, and next actions.
5. Coordinate work between Jerry and Tom through shared project files.
6. Write back lessons, decisions, and important context.
7. Protect private data and avoid sharing memory in the wrong context.
8. Automatically apply Brain Model-related tasks, messages, and timed instructions to the project record.

## Initial Architecture

- **Input layer:** chat messages, notes, files, links, future connectors.
- **Memory layer:** daily logs, long-term memory, project memory, people memory, decisions.
- **Reasoning layer:** planning, reflection, task decomposition, critique.
- **Action layer:** code writing, browser automation, email/calendar actions with permission.
- **Coordination layer:** shared files that Jerry and Tom can both read and update.
- **Evaluation layer:** test scenarios that measure recall, usefulness, privacy, and execution quality.

## Success Criteria for v0.1

- Recalls correct project context without hallucinating.
- Separates facts, assumptions, and open questions.
- Learns from Shadhin's corrections.
- Lets Jerry and Tom exchange useful updates asynchronously.
- Produces useful plans and code with traceable decisions.
- Passes practical tests on real tasks after one month.

## Current Status

- Project initialized.
- Shared communication path created at: `/home/ubuntu/.openclaw/workspace/projects/brain-model/shared/`
- Operating rules created at: `/home/ubuntu/.openclaw/workspace/projects/brain-model/OPERATING_RULES.md`
