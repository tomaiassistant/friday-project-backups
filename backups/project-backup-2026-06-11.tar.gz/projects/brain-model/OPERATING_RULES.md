# Brain Model Operating Rules

## Automatic Project Application

When Shadhin gives Jerry or Tom a Brain Model-related task, the task should be applied to this project automatically.

This means the agent should:

1. Capture the instruction in project memory or task files.
2. Create or update the relevant task file.
3. Record important decisions.
4. Write useful coordination messages for the other agent.
5. Preserve implementation notes and results.
6. Keep the project roadmap updated when scope changes.

## Timed Instructions

When Shadhin gives a specific time for work, the agent should schedule the work instead of relying on memory.

Use scheduled jobs for:

- exact-time work
- delayed follow-ups
- reminders
- timed project checks
- scheduled implementation windows

The scheduled task should reference this project path:

```text
/home/ubuntu/.openclaw/workspace/projects/brain-model/
```

## Task Intake Flow

For each new Brain Model task:

1. Create a task file in `tasks/`.
2. Add a short log entry in `shared/logs/`.
3. If Tom needs context, create a message in `shared/inbox/`.
4. If the task changes architecture, create a decision file in `decisions/`.
5. After completion, update the task status and write a result summary.

## Agent Coordination

Jerry and Tom should treat the project files as the shared source of truth.

- Do not keep important context only in chat.
- Do not rely on hidden memory for project-critical information.
- If a task affects the Brain Model, write it down.
- If work is scheduled for later, include the exact time, timezone, and expected action.

