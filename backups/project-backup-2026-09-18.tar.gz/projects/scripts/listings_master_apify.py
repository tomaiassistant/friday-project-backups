#!/usr/bin/env python3
"""
Listings Master Database — Using Hermes Browser + Apify Rotation
"""

import json
import gspread
import subprocess
from datetime import datetime
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import time

# Google Sheets OAuth
GOOGLE_OAUTH_TOKEN = {
    "token": "ya29.a0AT3oNZ-JW_7EcYKUWaIZKZdStO074Ke4ssKwy9NUiYW-7GZmcdieSHOK17ZDM2Nn-6hlOFkDhEFQ84ii9II5b40R8Lcv4I-4easnsR6HNbDDfCvrZsuqYuGRpekGrDAtMpYZkkuFYDy9mTFEiRO5531B_9DbaVg9ExiENYSiWlqmU5rQVJoBKFmeDYkn50fk1pKn65rsaCgYKAVMSARESFQHGX2Mi_6x5Y7Q6SJLMb6PBOgqJjQ0207",
    "refresh_token": "1//0gTCbf_lOFNEiCgYIARAAGBASNwF-L9IrC0-1Ei4F_RlCfukXzLQnzf4_AhB1Lotaz3hKMXZQTYqWO5r8mh1oasZJyd6RxV3Gq2A",
    "token_uri": "https://oauth2.googleapis.com/token",
    "client_id": "902478705286-ls0579voqir3hd8fue7mks9hjl0gm845.apps.googleusercontent.com",
    "client_secret": "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",
    "type": "authorized_user"
}

SHEET_ID = "13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148"
TARGET_SHEET = "listings_master"

APIFY_KEYS = [
    "apify_api_QWeSTJkvVJiKMwn1OaH6O6AQi4wAQl0yM1Ig",
    "apify_api_9boeCGv1pkontsvDSB74ge44q6UC5w2PhmRh",
    "apify_api_v3Q1GwVd5F29oC6q4xWYfZOrgzexE02bxMHV"
]

URLS = {
    "BizBuySell": "https://www.bizbuysell.com/ontario-canada-businesses-for-sale/?q=aTI9ODgsMTM2LDE0MSw4MSw4OSwyNywyMiwxMTgsMzEsNTcsMTE1LDE4OCwxLDIwLDMwLDIwNiw3OCwyMTMmbHQ9MzAsNDAsODA%3D",
    "BusinessesForSale": "https://canada.businessesforsale.com/canadian/search?CategoryIds=1299301&CategoryIds=1387201&CategoryIds=1316601&CategoryIds=1294601&CategoryIds=1294101&CategoryIds=1293501&CategoryIds=1389001&CategoryIds=1360201&CategoryIds=1293801&CategoryIds=1293901&CategoryIds=1293401&CategoryIds=1365401&RegionIds=1022301"
}

def scrape_with_apify(url, source, key_index=0):
    """Scrape with Apify Web Scraper + proper pageFunction"""
    import requests
    
    key = APIFY_KEYS[key_index % len(APIFY_KEYS)]
    actor_id = "moJRLRc85AitArpNN"  # Web Scraper
    
    page_function = """
async function pageFunction(context) {
  const { page } = context;
  await page.waitForTimeout(1500);
  
  let listings = [];
  
  // Try to extract all links with meaningful text
  const links = await page.$$eval('a', anchors => {
    return anchors.map(a => ({
      text: a.innerText || a.textContent || '',
      href: a.href || ''
    })).filter(l => l.text && l.text.length > 10 && l.text.length < 300 && l.href.length > 20);
  });
  
  // Remove duplicates
  const seen = new Set();
  const unique = [];
  for (const l of links) {
    if (!seen.has(l.href)) {
      unique.push({title: l.text, url: l.href});
      seen.add(l.href);
    }
  }
  
  return unique.slice(0, 100);
}
"""
    
    payload = {
        "startUrls": [{"url": url}],
        "pageFunction": page_function,
        "useChrome": True,
        "maxPagesPerCrawl": 1,
        "maxCrawlDepth": 0
    }
    
    try:
        r = requests.post(
            f"https://api.apify.com/v2/acts/{actor_id}/runs?token={key}",
            json=payload,
            timeout=30
        )
        
        if r.status_code != 201:
            return []
        
        run_id = r.json()["data"]["id"]
        
        # Wait for completion
        for _ in range(40):
            time.sleep(2)
            r = requests.get(
                f"https://api.apify.com/v2/acts/{actor_id}/runs/{run_id}?token={key}",
                timeout=10
            )
            
            status = r.json()["data"]["status"]
            if status in ["SUCCEEDED", "FAILED"]:
                break
        
        # Get dataset
        r = requests.get(
            f"https://api.apify.com/v2/acts/{actor_id}/runs/{run_id}?token={key}",
            timeout=10
        )
        
        dataset_id = r.json()["data"].get("defaultDatasetId", "")
        
        if not dataset_id:
            return []
        
        # Get items
        r = requests.get(
            f"https://api.apify.com/v2/datasets/{dataset_id}/items?token={key}&format=json",
            timeout=10
        )
        
        items = r.json()
        if isinstance(items, list):
            listings = []
            for item in items:
                if isinstance(item, dict) and not item.get("#error"):
                    if "title" in item and "url" in item:
                        listings.append(item)
            return listings
        
        return []
    
    except Exception as e:
        print(f"  ❌ Apify error: {e}")
        return []

def get_existing_urls():
    """Load existing URLs"""
    try:
        creds = Credentials.from_authorized_user_info(GOOGLE_OAUTH_TOKEN)
        creds.refresh(Request())
        gc = gspread.authorize(creds)
        
        ws = gc.open_by_key(SHEET_ID).worksheet(TARGET_SHEET)
        rows = ws.get_all_values()
        
        urls = set()
        for row in rows[1:]:
            if len(row) > 3 and row[3]:
                urls.add(row[3].strip())
        
        print(f"✓ Loaded {len(urls)} existing URLs")
        return urls
    except Exception as e:
        print(f"⚠️  Error: {e}")
        return set()

def add_to_sheet(listings, source):
    """Add new rows to sheet"""
    if not listings:
        return 0
    
    try:
        creds = Credentials.from_authorized_user_info(GOOGLE_OAUTH_TOKEN)
        creds.refresh(Request())
        gc = gspread.authorize(creds)
        
        ws = gc.open_by_key(SHEET_ID).worksheet(TARGET_SHEET)
        
        rows = [
            [source, l.get("title", "")[:100], "N/A", l.get("url", ""), "N/A", datetime.now().strftime("%Y-%m-%d")]
            for l in listings if l.get("url")
        ]
        
        if rows:
            ws.append_rows(rows)
            print(f"  ✓ Added {len(rows)} rows")
            return len(rows)
        
        return 0
    except Exception as e:
        print(f"  ❌ Failed: {e}")
        return 0

def send_email(biz_count, bfs_count):
    """Send results"""
    total = biz_count + bfs_count
    body = f"""Listings Master Database — Weekly Scrape
==========================================

Run: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Results:
--------
BizBuySell: {biz_count} listings added
BusinessesForSale: {bfs_count} listings added
Total: {total} new listings

Sheet: https://docs.google.com/spreadsheets/d/{SHEET_ID}/edit

Status: ✓ Complete
"""
    
    try:
        proc = subprocess.Popen(["sendmail", "touhiduliet@gmail.com"], stdin=subprocess.PIPE, text=True)
        proc.communicate(input=f"Subject: Listings Master Database — Weekly Scrape\n\n{body}")
        print("✓ Email sent")
    except Exception as e:
        print(f"⚠️  Email: {e}")

def main():
    print("\n" + "=" * 70)
    print("Listings Master Database Automation — Apify Web Scraper")
    print(f"Run: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    
    existing_urls = get_existing_urls()
    stats = {}
    
    for source, url in URLS.items():
        print(f"\n--- {source} ---")
        
        listings = scrape_with_apify(url, source)
        if not listings:
            print(f"  ⚠️  0 listings extracted")
            stats[source] = 0
            continue
        
        print(f"  ✓ Got {len(listings)} listings")
        
        new = [l for l in listings if l.get("url") not in existing_urls]
        print(f"  ✓ {len(new)} new")
        
        added = add_to_sheet(new, source)
        stats[source] = added
        
        for l in new:
            existing_urls.add(l.get("url", ""))
    
    send_email(stats.get("BizBuySell", 0), stats.get("BusinessesForSale", 0))
    
    total = sum(stats.values())
    print("\n" + "=" * 70)
    print(f"✓ Complete: {total} new listings added")
    for source, count in stats.items():
        print(f"  {source}: {count}")
    print("=" * 70 + "\n")

if __name__ == "__main__":
    main()
