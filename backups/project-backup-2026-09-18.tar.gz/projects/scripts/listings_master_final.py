#!/usr/bin/env python3
"""
Listings Master Database - Apify Scraper
Uses Apify Playwright + Firefox with correct pageFunction
"""

import requests
import time
import json
import gspread
from datetime import datetime
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials

# Config
API_KEY = "apify_api_QWeSTJkvVJiKMwn1OaH6O6AQi4wAQl0yM1Ig"
ACTOR_ID = "YrQuEkowkNCLdk4j2"

GOOGLE_OAUTH_TOKEN = {
    "token": "ya29.a0AT3oNZ-JW_7EcYKUWaIZKZdStO074Ke4ssKwy9NUiYW-7GZmcdieSHOK17ZDM2Nn-6hlOFkDhEFQ84ii9II5b40R8Lcv4I-4easnsR6HNbDDfCvrZsuqYuGRpekGrDAtMpYZkkuFYDy9mTFEiRO5531B_9DbaVg9ExiENYSiWlqmU5rQVJoBKFmeDYkn50fk1pKn65rsaCgYKAVMSARESFQHGX2Mi_6x5Y7Q6SJLMb6PBOgqJjQ0207",
    "refresh_token": "1//0gTCbf_lOFNEiCgYIARAAGBASNwF-L9IrC0-1Ei4F_RlCfukXzLQnzf4_AhB1Lotaz3hKMXZQTYqWO5r8mh1oasZJyd6RxV3Gq2A",
    "token_uri": "https://oauth2.googleapis.com/token",
    "client_id": "902478705286-ls0579voqir3hd8fue7mks9hjl0gm845.apps.googleusercontent.com",
    "client_secret": "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",
    "type": "authorized_user"
}

SHEET_ID = "13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148"
TARGET_SHEET = "listings_master"

URLS = {
    "BizBuySell": "https://www.bizbuysell.com/ontario-canada-businesses-for-sale/?q=aTI9ODgsMTM2LDE0MSw4MSw4OSwyNywyMiwxMTgsMzEsNTcsMTE1LDE4OCwxLDIwLDMwLDIwNiw3OCwyMTMmbHQ9MzAsNDAsODA%3D",
    "BusinessesForSale": "https://canada.businessesforsale.com/canadian/search?CategoryIds=1299301&CategoryIds=1387201&CategoryIds=1316601&CategoryIds=1294601&CategoryIds=1294101&CategoryIds=1293501&CategoryIds=1389001&CategoryIds=1360201&CategoryIds=1293801&CategoryIds=1293901&CategoryIds=1293401&CategoryIds=1365401&RegionIds=1022301"
}

PAGE_FUNCTION = """
async function pageFunction(context) {
  const { page } = context;
  
  // Wait for page load
  await new Promise(resolve => setTimeout(resolve, 3000));
  
  const listings = [];
  
  // Get all links on the page
  const allLinks = await page.$$('a');
  
  for (const link of allLinks) {
    try {
      const href = await link.getAttribute('href');
      const text = await link.evaluate(el => el.innerText || el.textContent || '');
      const cleanText = text.trim();
      
      // Check if it's a listing link
      if (href && href.includes('/view/') && cleanText.length > 20 && cleanText.length < 300) {
        const fullUrl = href.startsWith('http') ? href : 'https://www.bizbuysell.com' + href;
        
        listings.push({
          title: cleanText,
          url: fullUrl,
          timestamp: new Date().toISOString()
        });
      }
    } catch (e) {
      // Skip error elements
    }
  }
  
  return listings;
}
"""

def scrape_source(source_name, url):
    """Scrape a single source via Apify"""
    print(f"\n[*] Scraping {source_name}...")
    
    payload = {
        "startUrls": [{"url": url}],
        "pageFunction": PAGE_FUNCTION,
        "browserType": "firefox",
        "maxCrawlDepth": 0,
        "maxPagesPerCrawl": 1
    }
    
    # Submit
    r = requests.post(
        f"https://api.apify.com/v2/acts/{ACTOR_ID}/runs?token={API_KEY}",
        json=payload,
        timeout=30
    )
    
    if r.status_code != 201:
        print(f"  ❌ Submit failed: {r.status_code}")
        return []
    
    run_id = r.json()["data"]["id"]
    print(f"  Task: {run_id}")
    
    # Wait for completion
    for i in range(180):
        time.sleep(3)
        r = requests.get(f"https://api.apify.com/v2/acts/{ACTOR_ID}/runs/{run_id}?token={API_KEY}")
        
        status = r.json()["data"]["status"]
        
        if i % 20 == 0:
            print(f"    [{i*3}s] {status}")
        
        if status in ["SUCCEEDED", "FAILED"]:
            break
    
    # Get dataset
    dataset_id = r.json()["data"].get("defaultDatasetId")
    if not dataset_id:
        print(f"  ❌ No dataset")
        return []
    
    r = requests.get(f"https://api.apify.com/v2/datasets/{dataset_id}/items?token={API_KEY}&limit=500")
    items = r.json()
    
    # Filter to listings
    listings = []
    for item in items:
        if isinstance(item, dict) and "title" in item and "url" in item:
            listings.append({
                "title": item["title"],
                "url": item["url"],
                "source": source_name
            })
    
    print(f"  ✓ Got {len(listings)} listings")
    return listings

def get_existing_urls():
    """Load existing URLs from sheet"""
    try:
        creds = Credentials.from_authorized_user_info(GOOGLE_OAUTH_TOKEN)
        creds.refresh(Request())
        gc = gspread.authorize(creds)
        ws = gc.open_by_key(SHEET_ID).worksheet(TARGET_SHEET)
        rows = ws.get_all_values()
        
        urls = set(row[6].strip() for row in rows[1:] if len(row) > 6 and row[6])
        print(f"✓ Existing URLs: {len(urls)}")
        return urls
    except Exception as e:
        print(f"❌ Error: {e}")
        return set()

def add_to_sheet(listings):
    """Add new listings to sheet"""
    if not listings:
        return 0
    
    try:
        creds = Credentials.from_authorized_user_info(GOOGLE_OAUTH_TOKEN)
        creds.refresh(Request())
        gc = gspread.authorize(creds)
        ws = gc.open_by_key(SHEET_ID).worksheet(TARGET_SHEET)
        
        rows = []
        for l in listings:
            listing_id = l["url"].split("/")[-2] if l.get("url") else "unknown"
            
            row = [
                "FALSE", listing_id, datetime.now().isoformat()+"Z", "N/A", "TRUE",
                l.get("source", ""), l.get("url", ""), listing_id, "",
                l.get("title", "")[:200]
            ] + [""] * 44
            
            rows.append(row)
        
        ws.append_rows(rows)
        print(f"✓ Added {len(rows)} rows")
        return len(rows)
    except Exception as e:
        print(f"❌ Error: {e}")
        return 0

def main():
    print("\n" + "="*70)
    print("LISTINGS MASTER DATABASE - Apify Scraper")
    print(f"Start: {datetime.now()}")
    print("="*70)
    
    existing = get_existing_urls()
    
    all_listings = []
    stats = {}
    
    for source, url in URLS.items():
        listings = scrape_source(source, url)
        new_listings = [l for l in listings if l["url"] not in existing]
        
        print(f"  → {len(new_listings)} new")
        stats[source] = len(new_listings)
        
        for l in new_listings:
            existing.add(l["url"])
        
        all_listings.extend(new_listings)
    
    # Add to sheet
    added = add_to_sheet(all_listings)
    
    print("\n" + "="*70)
    print(f"✓ COMPLETE: {added} new listings added")
    for source, count in stats.items():
        print(f"  {source}: {count}")
    print("="*70 + "\n")

if __name__ == "__main__":
    main()
