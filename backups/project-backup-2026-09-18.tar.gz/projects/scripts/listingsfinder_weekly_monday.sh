#!/usr/bin/env bash
set -euo pipefail

REPO="/root/projects/ListingsFinder-AI"
source "$REPO/.venv/bin/activate"
source "$HOME/.hermes/.env"
cd "$REPO"

python - <<'PY'
from __future__ import annotations

import hashlib
import os
import re
from dataclasses import asdict
from datetime import datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo
from urllib.parse import urlparse

from bs4 import BeautifulSoup

from listingsfinder.config import GOOGLE_SHEET_URL, RESEND_FROM_EMAIL
from listingsfinder.models import Listing, SearchCriteria, now_iso
from listingsfinder.parser import parse_mandate
from listingsfinder.queries import generate_queries
from listingsfinder.scraper import scrape_result
from listingsfinder.tmcp_client import tmcp_execute

SHEET_ID = re.search(r"/d/([a-zA-Z0-9-_]+)", GOOGLE_SHEET_URL).group(1)
EASTERN = ZoneInfo("America/New_York")
MANDATES_RANGE = "Mandates!A1:Q5000"
DEAL_SOURCES_RANGE = "Deal Sources!A1:I5000"
LISTINGS_RANGE = "Listings!A1:U5000"
SEARCH_RUNS_RANGE = "Search Runs!A1:K5000"
DUPLICATES_RANGE = "Duplicates!A1:G5000"
POTENTIAL_RANGE = "Potential New Sources!A1:I5000"


def col_letter(n: int) -> str:
    out = ""
    while n:
        n, rem = divmod(n - 1, 26)
        out = chr(65 + rem) + out
    return out


def tmcp_read(sheet_range: str) -> list[list[Any]]:
    result = tmcp_execute(
        "sheets",
        "sheets.read",
        {"spreadsheet_id": SHEET_ID, "range": sheet_range},
    )
    if not result or not result.get("success"):
        raise RuntimeError(result or f"TMCP read failed for {sheet_range}")
    return result["result"].get("values", []) or []


def tmcp_write(sheet_range: str, values: list[list[Any]]) -> dict[str, Any]:
    result = tmcp_execute(
        "sheets",
        "sheets.write",
        {"spreadsheet_id": SHEET_ID, "range": sheet_range, "values": values},
    )
    if not result or not result.get("success"):
        raise RuntimeError(result or f"TMCP write failed for {sheet_range}")
    return result["result"]


def tmcp_email(to_email: str, subject: str, body: str) -> dict[str, Any]:
    result = tmcp_execute(
        "resend",
        "resend.send_email",
        {
            "from": RESEND_FROM_EMAIL,
            "to": [to_email],
            "subject": subject,
            "text": body,
        },
    )
    if not result or not result.get("success"):
        raise RuntimeError(result or "TMCP email failed")
    return result["result"]


def parse_dt(value):
    if not value:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%m/%d/%Y", "%m/%d/%Y %H:%M:%S"):
        try:
            return datetime.strptime(str(value), fmt).replace(tzinfo=EASTERN)
        except ValueError:
            pass
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return parsed.astimezone(EASTERN) if parsed.tzinfo else parsed.replace(tzinfo=EASTERN)
    except ValueError:
        return None


def next_run(now: datetime, frequency: str):
    frequency = (frequency or "").strip().lower()
    base = now.replace(hour=5, minute=0, second=0, microsecond=0)
    if frequency == "daily":
        return base + (timedelta(days=1) if now >= base else timedelta())
    if frequency == "weekly":
        return base + timedelta(days=7)
    if frequency == "monthly":
        month = base.month + 1
        year = base.year + (1 if month == 13 else 0)
        month = 1 if month == 13 else month
        return base.replace(year=year, month=month)
    return None


def to_dict_rows(values: list[list[Any]]) -> list[dict[str, Any]]:
    if not values:
        return []
    headers = [str(h or "").strip() for h in values[0]]
    rows = []
    for row in values[1:]:
        item = {}
        for idx, header in enumerate(headers):
            if header:
                item[header] = row[idx] if idx < len(row) else ""
        rows.append(item)
    return rows


def row_map(values: list[list[Any]]) -> dict[str, int]:
    if not values:
        return {}
    return {str(h or "").strip(): i + 1 for i, h in enumerate(values[0]) if str(h or "").strip()}


def append_rows(tab: str, headers: list[str], rows: list[dict[str, Any]]):
    if not rows:
        return
    existing = tmcp_read(f"{tab}!A1:{col_letter(len(headers))}5000")
    next_row = len(existing) + 1 if existing else 2
    matrix = [[row.get(h, "") for h in headers] for row in rows]
    tmcp_write(f"{tab}!A{next_row}", matrix)


def due_mandates(rows: list[dict[str, Any]], now: datetime):
    due = []
    for idx, row in enumerate(rows, start=2):
        frequency = str(row.get("Frequency", "One-time") or "One-time").strip().lower()
        if frequency not in {"one-time", "daily", "weekly", "monthly"} or frequency == "one-time":
            continue
        next_due = parse_dt(row.get("Next Run"))
        last_run = parse_dt(row.get("Last Run"))
        if next_due and next_due > now:
            continue
        if not next_due and last_run:
            next_due = next_run(last_run, frequency)
            if next_due and next_due > now:
                continue
        due.append((idx, row, frequency))
    return due


mandates_values = tmcp_read(MANDATES_RANGE)
mandate_rows = to_dict_rows(mandates_values)
mandate_headers = mandates_values[0] if mandates_values else []
source_values = tmcp_read(DEAL_SOURCES_RANGE)
source_rows = to_dict_rows(source_values)

now = datetime.now(EASTERN)
results = []
for row_index, row, frequency in due_mandates(mandate_rows, now):
    mandate = row.get("Original Query") or row.get("Search Query") or ""
    if not mandate:
        continue
    criteria = parse_mandate(mandate)
    queries = generate_queries(criteria, source_rows)[:12]
    raw = []
    for q in queries:
        search = tmcp_execute("serper", "serper.search", {"query": q, "num": 10, "gl": "ca", "hl": "en"})
        if not search or not search.get("success"):
            continue
        organic = (search.get("result", {}) or {}).get("organic", []) or []
        for item in organic:
            raw.append({
                "title": item.get("title", ""),
                "url": item.get("link", ""),
                "snippet": item.get("snippet", ""),
                "source": "Serper",
                "query": q,
            })
    seen = set()
    results_rows: list[Listing] = []
    for item in raw:
        url = item.get("url", "")
        if not url or url in seen:
            continue
        seen.add(url)
        try:
            results_rows.append(scrape_result(item, criteria.industry, criteria.location))
        except Exception as exc:
            results_rows.append(Listing(
                source=item.get("source", ""),
                source_url=url,
                listing_title=item.get("title", ""),
                description=item.get("snippet", ""),
                industry=criteria.industry,
                location=criteria.location,
                scrape_date=now_iso(),
                notes=f"scrape_error={exc}",
            ))
    listing_dicts = [asdict(l) | {"Master Listing ID": l.master_listing_id, "Mandate ID": row.get("Mandate ID", "")} for l in results_rows]
    append_rows(
        "Listings",
        [
            "Master Listing ID", "Listing ID", "Source", "Source URL", "Listing Title", "Company Name",
            "Industry", "Location", "Asking Price", "Revenue", "Cash Flow", "EBITDA", "Description",
            "Contact Name", "Contact Email", "Contact Phone", "Listing Date", "Scrape Date", "Status",
            "Notes", "Mandate ID",
        ],
        [
            {
                "Master Listing ID": item.get("master_listing_id", ""),
                "Listing ID": item.get("listing_id", ""),
                "Source": item.get("source", ""),
                "Source URL": item.get("source_url", ""),
                "Listing Title": item.get("listing_title", ""),
                "Company Name": item.get("company_name", ""),
                "Industry": item.get("industry", ""),
                "Location": item.get("location", ""),
                "Asking Price": item.get("asking_price", ""),
                "Revenue": item.get("revenue", ""),
                "Cash Flow": item.get("cash_flow", ""),
                "EBITDA": item.get("ebitda", ""),
                "Description": item.get("description", ""),
                "Contact Name": item.get("contact_name", ""),
                "Contact Email": item.get("contact_email", ""),
                "Contact Phone": item.get("contact_phone", ""),
                "Listing Date": item.get("listing_date", ""),
                "Scrape Date": item.get("scrape_date", ""),
                "Status": item.get("status", "New"),
                "Notes": item.get("notes", ""),
                "Mandate ID": row.get("Mandate ID", ""),
            }
            for item in listing_dicts
        ],
    )
    run_id = f"RUN-{hashlib.sha1((mandate + now.isoformat()).encode()).hexdigest()[:8].upper()}"
    run_row = {
        "Run ID": run_id,
        "Date": now.isoformat(timespec="seconds"),
        "User": row.get("User", "Dealio Advisor"),
        "Search Query": mandate,
        "Industry": criteria.industry,
        "Location": criteria.location,
        "Sources Searched": str(len(source_rows)),
        "Listings Found": str(len(results_rows)),
        "Duplicates Removed": "0",
        "New Sources Found": "0",
        "Notes": "Hermes/TMCP automation run",
    }
    append_rows("Search Runs", ["Run ID", "Date", "User", "Search Query", "Industry", "Location", "Sources Searched", "Listings Found", "Duplicates Removed", "New Sources Found", "Notes"], [run_row])
    # Update the mandate row
    mandate_map = row_map(mandates_values)
    if mandate_map:
        last_run_col = col_letter(mandate_map.get("Last Run", 0))
        next_run_col = col_letter(mandate_map.get("Next Run", 0))
        status_col = col_letter(mandate_map.get("Status", 0))
        nr = next_run(now, frequency)
        if last_run_col:
            tmcp_write(f"Mandates!{last_run_col}{row_index}", [[now.isoformat(timespec='seconds')]])
        if next_run_col and nr:
            tmcp_write(f"Mandates!{next_run_col}{row_index}", [[nr.isoformat(timespec='seconds')]])
        if status_col:
            tmcp_write(f"Mandates!{status_col}{row_index}", [["Scheduled"]])
    notify_email = row.get("Notify Email") or os.getenv("DEFAULT_NOTIFY_EMAIL") or "touhiduliet@gmail.com"
    if notify_email and results_rows:
        body = "\n".join([f"{item.listing_title} - {item.source_url}" for item in results_rows[:25]])
        email_result = tmcp_email(notify_email, f"ListingsFinder: {len(results_rows)} listings found", body)
    else:
        email_result = None
    results.append({"mandate_id": row.get("Mandate ID", ""), "listings": len(results_rows), "email": bool(email_result)})

if results:
    if any(item["listings"] > 0 for item in results):
        total = sum(item["listings"] for item in results)
        print(f"ListingsFinder Monday run complete: {total} listing(s) processed across {len(results)} mandate(s).")
PY
