#!/usr/bin/env bash
set -euo pipefail

# Hermes memory and skills daily backup to GitHub repo
# Uses same GitHub credentials as other Hermes backups

ASKPASS="/root/.hermes/scripts/github-askpass-friday.sh"
HERMES_HOME="/root/.hermes"
WORKDIR="/tmp/hermes-mem-skills-backup"
REPO_NAME="hermes-memory-skills"
REPO_OWNER="tomaiassistant"

# Get GitHub token via askpass
GIT_TOKEN=$("$ASKPASS" "Password")

# Construct repo URL with token
REPO_URL="https://${REPO_OWNER}:${GIT_TOKEN}@github.com/${REPO_OWNER}/${REPO_NAME}.git"

# Ensure workdir clean
rm -rf "$WORKDIR"
mkdir -p "$WORKDIR"
cd "$WORKDIR"

# Initialize git repo if not already cloned
if [ ! -d ".git" ]; then
    # Try to clone existing repo; if fails, init new
    if git clone "$REPO_URL" . 2>/dev/null; then
        echo "Cloned existing repo $REPO_NAME"
    else
        echo "Repo not found or access denied; initializing new repo"
        git init
        git remote add origin "$REPO_URL"
        # Configure user
        git config user.name "Hermes Backup"
        git config user.email "hermes@example.com"
        # Create initial README if empty
        if [ ! -f README.md ]; then
            echo "# Hermes Memory and Skills Backup" > README.md
            echo "Daily backup of Hermes memory and skills directories." >> README.md
            git add README.md
            git commit -m "Initial commit"
        fi
    fi
else
    # Ensure remote URL is correct (with token)
    git remote set-url origin "$REPO_URL"
fi

# Copy memory and skills directories
mkdir -p memory skills
cp -rf "${HERMES_HOME}/memory"/* memory/ 2>/dev/null || true
cp -rf "${HERMES_HOME}/skills"/* skills/ 2>/dev/null || true

# Remove excluded caches etc. (optional)
find memory -type d -name "logs" -exec rm -rf {} + 2>/dev/null || true
find memory -type d -name "cache" -exec rm -rf {} + 2>/dev/null || true
find memory -type d -name "tmp" -exec rm -rf {} + 2>/dev/null || true
find skills -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find skills -type f -name "*.pyc" -delete 2>/dev/null || true

# Add changes
git add -A
# Check if there are changes to commit
if ! git diff --cached --quiet; then
    TIMESTAMP=$(date -u +"%Y-%m-%d %H:%M:%S UTC")
    git commit -m "chore: daily memory/skills backup $TIMESTAMP"
    # Push
    GIT_ASKPASS="$ASKPASS" GIT_TERMINAL_PROMPT=0 git push origin HEAD:main
    echo "Pushed memory/skills backup at $TIMESTAMP"
else
    echo "No changes in memory/skills; skipping commit"
fi

# Cleanup
cd /
rm -rf "$WORKDIR"