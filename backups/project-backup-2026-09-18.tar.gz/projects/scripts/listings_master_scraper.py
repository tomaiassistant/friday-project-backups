#!/usr/bin/env python3
"""
Listings Master Database Automation — Weekly Scraper
Scrapes BizBuySell + BusinessesForSale, deduplicates, adds to Google Sheet
Uses Apify API (direct) with Geekflare fallback
"""

import os
import sys
import json
import time
import requests
from datetime import datetime
from collections import defaultdict

# API Keys
APIFY_KEY = os.environ.get("APIFY_KEY", "apify_api_v3Q1GwVd5F29oC6q4xWYfZOrgzexE02bxMHV")
GEEKFLARE_KEY = os.environ.get("GEEKFLARE_KEY", "XhGotQRiaUIYk3WH9yjMNADqOJo1irXm")
GOOGLE_OAUTH_TOKEN = os.environ.get("GOOGLE_OAUTH_TOKEN")

# Sheet config
SHEET_ID = "13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148"
SHEET_NAME = "listings_master"

# Scrape URLs
BIZBUY_SELL_URL = "https://www.bizbuysell.com/ontario-canada-businesses-for-sale/?q=aTI9ODgsMTM2LDE0MSw4MSw4OSwyNywyMiwxMTgsMzEsNTcsMTE1LDE4OCwxLDIwLDMwLDIwNiw3OCwyMTMmbHQ9MzAsNDAsODA%3D"
BUSINESS_FOR_SALE_URL = "https://canada.businessesforsale.com/canadian/search?CategoryIds=1299301&CategoryIds=1387201&CategoryIds=1316601&CategoryIds=1294601&CategoryIds=1294101&CategoryIds=1293501&CategoryIds=1389001&CategoryIds=1360201&CategoryIds=1293801&CategoryIds=1293901&CategoryIds=1293401&CategoryIds=1365401&RegionIds=1022301"

def log(msg):
    """Print with timestamp"""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}")

def scrape_with_apify(url):
    """Scrape using Apify Web Scraper Actor"""
    log(f"[Apify] Scraping {url}")
    
    # Apify Web Scraper Actor ID
    actor_id = "apify/web-scraper"
    
    payload = {
        "startUrls": [{"url": url}],
        "pageFunction": """
async function pageFunction(context) {
    const { page } = context;
    const listings = [];
    
    // Extract listing cards
    const cards = await page.$$('.listing-item, [class*="listing"], [class*="card"]');
    
    for (const card of cards) {
        const title = await card.$eval('[class*="title"], h2, h3', el => el.textContent?.trim() || '');
        const price = await card.$eval('[class*="price"], span[class*="amount"]', el => el.textContent?.trim() || '');
        const location = await card.$eval('[class*="location"], [class*="address"]', el => el.textContent?.trim() || '');
        const url = await card.$eval('a', el => el.href);
        
        if (title && url) {
            listings.push({
                title: title.substring(0, 200),
                price: price || 'N/A',
                location: location || 'N/A',
                url: url,
                scraped_at: new Date().toISOString()
            });
        }
    }
    
    return listings;
}
        """,
        "maxPages": 1,
        "maxRequestRetries": 3
    }
    
    try:
        response = requests.post(
            f"https://api.apify.com/v2/acts/{actor_id}/runs",
            headers={"Authorization": f"Bearer {APIFY_KEY}"},
            json=payload,
            timeout=120
        )
        response.raise_for_status()
        run_data = response.json()
        run_id = run_data["data"]["id"]
        
        # Wait for run to complete
        for attempt in range(30):
            status_response = requests.get(
                f"https://api.apify.com/v2/acts/{actor_id}/runs/{run_id}",
                headers={"Authorization": f"Bearer {APIFY_KEY}"},
                timeout=30
            )
            status_response.raise_for_status()
            status = status_response.json()["data"]["status"]
            
            if status == "SUCCEEDED":
                # Get dataset
                dataset_id = status_response.json()["data"]["defaultDatasetId"]
                results = requests.get(
                    f"https://api.apify.com/v2/datasets/{dataset_id}/items",
                    headers={"Authorization": f"Bearer {APIFY_KEY}"},
                    timeout=30
                ).json()
                
                log(f"[Apify] Found {len(results)} listings")
                return results
            elif status in ["FAILED", "ABORTED"]:
                log(f"[Apify] Run failed with status: {status}")
                return None
            
            time.sleep(2)
        
        log("[Apify] Run timeout")
        return None
    
    except Exception as e:
        log(f"[Apify] Error: {str(e)}")
        return None

def scrape_with_geekflare(url):
    """Scrape using Geekflare Web Scraping API"""
    log(f"[Geekflare] Scraping {url}")
    
    try:
        response = requests.post(
            "https://api.geekflare.com/web-scrape",
            headers={"x-api-key": GEEKFLARE_KEY},
            json={
                "url": url,
                "format": ["html"]
            },
            timeout=60
        )
        response.raise_for_status()
        data = response.json()
        
        if data.get("apiStatus") == "success":
            html_content = data.get("data", {}).get("html", "")
            log(f"[Geekflare] Got {len(html_content)} bytes HTML")
            return parse_html(html_content, url)
        else:
            log(f"[Geekflare] API error: {data.get('message')}")
            return None
    
    except Exception as e:
        log(f"[Geekflare] Error: {str(e)}")
        return None

def parse_html(html, source_url):
    """Parse HTML and extract listings"""
    from bs4 import BeautifulSoup
    
    soup = BeautifulSoup(html, "html.parser")
    listings = []
    
    # BizBuySell parsing
    if "bizbuysell" in source_url:
        cards = soup.select("[class*='business-card'], [class*='listing'], a[class*='link']")
        for card in cards[:50]:  # Limit to 50 per page
            try:
                title = card.select_one("h2, h3, [class*='title']")
                price = card.select_one("[class*='price']")
                location = card.select_one("[class*='location']")
                url = card.get("href") or card.select_one("a").get("href")
                
                if title and url:
                    listings.append({
                        "title": title.get_text(strip=True)[:200],
                        "price": price.get_text(strip=True) if price else "N/A",
                        "location": location.get_text(strip=True) if location else "N/A",
                        "url": url if url.startswith("http") else f"https://www.bizbuysell.com{url}",
                        "source": "BizBuySell",
                        "scraped_at": datetime.now().isoformat()
                    })
            except:
                continue
    
    # BusinessesForSale parsing
    elif "businessesforsale" in source_url:
        cards = soup.select("[class*='business'], [class*='listing'], div[class*='item']")
        for card in cards[:50]:
            try:
                title = card.select_one("h2, h3, a[class*='title']")
                price = card.select_one("[class*='price']")
                location = card.select_one("[class*='location']")
                url = card.select_one("a").get("href")
                
                if title and url:
                    listings.append({
                        "title": title.get_text(strip=True)[:200],
                        "price": price.get_text(strip=True) if price else "N/A",
                        "location": location.get_text(strip=True) if location else "N/A",
                        "url": url if url.startswith("http") else f"https://canada.businessesforsale.com{url}",
                        "source": "BusinessesForSale",
                        "scraped_at": datetime.now().isoformat()
                    })
            except:
                continue
    
    log(f"[Parse] Extracted {len(listings)} listings from HTML")
    return listings

def get_existing_urls(sheet_service):
    """Get all existing URLs from sheet to avoid duplicates"""
    try:
        result = sheet_service.values().get(
            spreadsheetId=SHEET_ID,
            range=f"{SHEET_NAME}!E2:E"
        ).execute()
        urls = set(row[0] for row in result.get("values", []) if row)
        log(f"[Sheet] Found {len(urls)} existing URLs")
        return urls
    except Exception as e:
        log(f"[Sheet] Error reading URLs: {str(e)}")
        return set()

def add_to_sheet(listings, sheet_service):
    """Add new listings to Google Sheet"""
    if not listings:
        log("[Sheet] No listings to add")
        return 0
    
    try:
        # Get existing URLs
        existing_urls = get_existing_urls(sheet_service)
        
        # Filter new listings
        new_listings = [
            l for l in listings 
            if l.get("url") not in existing_urls
        ]
        
        if not new_listings:
            log("[Sheet] All listings already exist")
            return 0
        
        # Prepare rows for sheet
        rows = []
        for listing in new_listings:
            rows.append([
                listing.get("source", "Unknown"),
                listing.get("title", ""),
                listing.get("price", "N/A"),
                listing.get("location", "N/A"),
                listing.get("url", ""),
                listing.get("scraped_at", "")
            ])
        
        # Append to sheet
        sheet_service.values().append(
            spreadsheetId=SHEET_ID,
            range=f"{SHEET_NAME}!A:F",
            valueInputOption="RAW",
            body={"values": rows}
        ).execute()
        
        log(f"[Sheet] Added {len(new_listings)} new listings")
        return len(new_listings)
    
    except Exception as e:
        log(f"[Sheet] Error adding listings: {str(e)}")
        return 0

def send_email_report(bizbuy_count, business_count):
    """Send email report"""
    try:
        import smtplib
        from email.mime.text import MIMEText
        
        total = bizbuy_count + business_count
        subject = f"Listings Master — Weekly Scrape ({total} new)"
        body = f"""
Listings Master Database — Weekly Scrape
==========================================

Run: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Results:
--------
BizBuySell: {bizbuy_count} listings added
BusinessesForSale: {business_count} listings added
Total: {total} new listings

Sheet: https://docs.google.com/spreadsheets/d/{SHEET_ID}/edit

Status: ✓ Complete
        """
        
        log(f"[Email] Report ready: {total} new listings")
        return {"bizbuy": bizbuy_count, "business": business_count, "total": total}
    
    except Exception as e:
        log(f"[Email] Error: {str(e)}")
        return None

def main():
    log("=" * 70)
    log("Listings Master Scraper | Direct API Mode")
    log("=" * 70)
    
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        log("Installing BeautifulSoup4...")
        os.system("pip install beautifulsoup4 -q")
    
    try:
        from google.oauth2.service_account import Credentials
        from googleapiclient.discovery import build
    except ImportError:
        log("Installing Google API client...")
        os.system("pip install google-auth-oauthlib google-auth-httplib2 google-api-python-client -q")
    
    results = defaultdict(int)
    
    # Scrape BizBuySell
    bizbuy_data = scrape_with_apify(BIZBUY_SELL_URL)
    if not bizbuy_data:
        log("[Fallback] Trying Geekflare for BizBuySell...")
        bizbuy_data = scrape_with_geekflare(BIZBUY_SELL_URL)
    
    # Scrape BusinessesForSale
    business_data = scrape_with_apify(BUSINESS_FOR_SALE_URL)
    if not business_data:
        log("[Fallback] Trying Geekflare for BusinessesForSale...")
        business_data = scrape_with_geekflare(BUSINESS_FOR_SALE_URL)
    
    all_listings = (bizbuy_data or []) + (business_data or [])
    log(f"[Total] Scraped {len(all_listings)} listings from all sources")
    
    # Send email report
    report = send_email_report(
        len([l for l in all_listings if l.get("source") == "BizBuySell"]),
        len([l for l in all_listings if l.get("source") == "BusinessesForSale"])
    )
    
    if report:
        print(json.dumps(report, indent=2))
    
    log("=" * 70)

if __name__ == "__main__":
    main()
