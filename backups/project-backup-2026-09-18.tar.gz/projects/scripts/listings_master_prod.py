#!/usr/bin/env python3
"""Listings Master Database - Scrapes weekly via Scrape.do (anti-bot)"""

import json
import gspread
import subprocess
from datetime import datetime
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials

# Your Google OAuth token
GOOGLE_OAUTH={"token": "ya29.a0AT3oNZ-JW_7EcYKUWaIZKZdStO074Ke4ssKwy9NUiYW-7GZmcdieSHOK17ZDM2Nn-6hlOFkDhEFQ84ii9II5b40R8Lcv4I-4easnsR6HNbDDfCvrZsuqYuGRpekGrDAtMpYZkkuFYDy9mTFEiRO5531B_9DbaVg9ExiENYSiWlqmU5rQVJoBKFmeDYkn50fk1pKn65rsaCgYKAVMSARESFQHGX2Mi_6x5Y7Q6SJLMb6PBOgqJjQ0207", "refresh_token": "1//0gTCbf_lOFNEiCgYIARAAGBASNwF-L9IrC0-1Ei4F_RlCfukXzLQnzf4_AhB1Lotaz3hKMXZQTYqWO5r8mh1oasZJyd6RxV3Gq2A", "token_uri": "https://oauth2.googleapis.com/token", "client_id": "902478705286-ls0579voqir3hd8fue7mks9hjl0gm845.apps.googleusercontent.com", "client_secret": "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", "type": "authorized_user"}

SHEET_ID = "13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148"
TARGET_SHEET = "listings_master"
EMAIL_TO = "touhiduliet@gmail.com"

URLS = {"BizBuySell": "https://www.bizbuysell.com/ontario-canada-businesses-for-sale/?q=aTI9ODgsMTM2LDE0MSw4MSw4OSwyNywyMiwxMTgsMzEsNTcsMTE1LDE4OCwxLDIwLDMwLDIwNiw3OCwyMTMmbHQ9MzAsNDAsODA%3D", "BusinessesForSale": "https://canada.businessesforsale.com/canadian/search?CategoryIds=1299301"}

def get_existing():
    creds = Credentials.from_authorized_user_info(GOOGLE_OAUTH)
    creds.refresh(Request())
    gc = gspread.authorize(creds)
    ws = gc.open_by_key(SHEET_ID).worksheet(TARGET_SHEET)
    rows = ws.get_all_values()
    urls = set(row[6].strip() for row in rows[1:] if len(row) > 6 and row[6])
    return urls

def add_to_sheet(listings):
    if not listings: return 0
    creds = Credentials.from_authorized_user_info(GOOGLE_OAUTH)
    creds.refresh(Request())
    gc = gspread.authorize(creds)
    ws = gc.open_by_key(SHEET_ID).worksheet(TARGET_SHEET)
    rows = []
    for l in listings:
        lid = l["url"].split("/")[-2]
        row = ["FALSE", lid, datetime.now().isoformat()+"Z", "N/A", "TRUE", l.get("source", ""), l.get("url", ""), lid, "", l.get("title", "")[:200]] + [""] * 44
        rows.append(row)
    ws.append_rows(rows)
    return len(rows)

def main():
    print(f"\n{'='*70}\nListings Master - Weekly Scrape\nRun: {datetime.now()}\n{'='*70}")
    existing = get_existing()
    print(f"Existing URLs: {len(existing)}")
    print("\n⚠️  BLOCKED: Scrape.do authorization required in TMCP")
    print(f"   Sheet: {SHEET_ID}")
    print(f"   Email: {EMAIL_TO}")

if __name__ == "__main__":
    main()
