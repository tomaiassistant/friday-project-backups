#!/usr/bin/env bash
set -euo pipefail

# Backup Hermes .hermes directory (excluding caches, logs, etc.) to a zip file
# Keeps only the latest backup (overwrites previous)

HERMES_HOME="/root/.hermes"
BACKUP_DIR="/root/backups/hermes"
BACKUP_FILE="${BACKUP_DIR}/hermes-backup-latest.zip"

# Directories to exclude from backup
EXCLUDE_DIRS=("logs" "audio_cache" "cache" "tmp" "tmp_logs" "node" "lsp" ".git" "__pycache__" "*.pyc")

# Ensure backup directory exists
mkdir -p "$BACKUP_DIR"

# Remove previous backup file (if exists) to avoid accumulating old backups
rm -f "$BACKUP_FILE"

# Build zip exclude patterns
ZIP_EXCLUDE=()
for dir in "${EXCLUDE_DIRS[@]}"; do
    ZIP_EXCLUDE+=(-x "*/$dir/*" -x "$dir/*")
done

# Create zip file
echo "Creating Hermes backup: $BACKUP_FILE"
cd "$HERMES_HOME"
zip -r -q "$BACKUP_FILE" . "${ZIP_EXCLUDE[@]}"

echo "Backup completed. Size: $(du -h "$BACKUP_FILE" | cut -f1)"
