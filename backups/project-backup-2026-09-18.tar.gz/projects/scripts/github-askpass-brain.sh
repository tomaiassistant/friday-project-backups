#!/bin/sh
case "$1" in
  *Username*) printf '%s\n' 'tomaiassistant' ;;
  *Password*) printf '%s\n' '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' ;;
  *) printf '\n' ;;
esac
