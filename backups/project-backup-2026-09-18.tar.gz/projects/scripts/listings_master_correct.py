#!/usr/bin/env python3
"""
Listings Master Database — Correct Format Scraper
Pulls from BizBuySell & BusinessesForSale, adds to sheet with proper columns
"""

import gspread
import requests
from datetime import datetime
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import time
import subprocess

GOOGLE_OAUTH_TOKEN = {
    "token": "ya29.a0AT3oNZ-JW_7EcYKUWaIZKZdStO074Ke4ssKwy9NUiYW-7GZmcdieSHOK17ZDM2Nn-6hlOFkDhEFQ84ii9II5b40R8Lcv4I-4easnsR6HNbDDfCvrZsuqYuGRpekGrDAtMpYZkkuFYDy9mTFEiRO5531B_9DbaVg9ExiENYSiWlqmU5rQVJoBKFmeDYkn50fk1pKn65rsaCgYKAVMSARESFQHGX2Mi_6x5Y7Q6SJLMb6PBOgqJjQ0207",
    "refresh_token": "1//0gTCbf_lOFNEiCgYIARAAGBASNwF-L9IrC0-1Ei4F_RlCfukXzLQnzf4_AhB1Lotaz3hKMXZQTYqWO5r8mh1oasZJyd6RxV3Gq2A",
    "token_uri": "https://oauth2.googleapis.com/token",
    "client_id": "902478705286-ls0579voqir3hd8fue7mks9hjl0gm845.apps.googleusercontent.com",
    "client_secret": "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",
    "type": "authorized_user"
}

SHEET_ID = "13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148"
TARGET_SHEET = "listings_master"

# Apify keys (3 accounts)
APIFY_KEYS = [
    "apify_api_QWeSTJkvVJiKMwn1OaH6O6AQi4wAQl0yM1Ig",
    "apify_api_9boeCGv1pkontsvDSB74ge44q6UC5w2PhmRh",
    "apify_api_v3Q1GwVd5F29oC6q4xWYfZOrgzexO02bxMHV"
]

URLS = {
    "BizBuySell": "https://www.bizbuysell.com/ontario-canada-businesses-for-sale/?q=aTI9ODgsMTM2LDE0MSw4MSw4OSwyNywyMiwxMTgsMzEsNTcsMTE1LDE4OCwxLDIwLDMwLDIwNiw3OCwyMTMmbHQ9MzAsNDAsODA%3D",
    "BusinessesForSale": "https://canada.businessesforsale.com/canadian/search?CategoryIds=1299301&CategoryIds=1387201&CategoryIds=1316601&CategoryIds=1294601&CategoryIds=1294101&CategoryIds=1293501&CategoryIds=1389001&CategoryIds=1360201&CategoryIds=1293801&CategoryIds=1293901&CategoryIds=1293401&CategoryIds=1365401&RegionIds=1022301"
}

def scrape_with_apify(url, source, key_index=0):
    """Scrape with Apify using proper pageFunction"""
    key = APIFY_KEYS[key_index % len(APIFY_KEYS)]
    actor_id = "moJRLRc85AitArpNN"  # Web Scraper
    
    page_function = """
function pageFunction(context) {
  var $ = context.jQuery;
  var listings = [];
  
  // BizBuySell structure
  $('a').each(function() {
    var $link = $(this);
    var text = $link.text().trim();
    var href = $link.attr('href') || '';
    
    if (text.length > 20 && text.length < 300 && href.includes('/view/')) {
      var existingUrl = listings.find(l => l.url === href);
      if (!existingUrl) {
        listings.push({
          title: text.substring(0, 200),
          url: href
        });
      }
    }
  });
  
  return listings.slice(0, 50);
}
"""
    
    payload = {
        "startUrls": [{"url": url}],
        "pageFunction": page_function,
        "maxCrawlDepth": 0,
        "useChrome": True
    }
    
    try:
        print(f"  Submitting to Apify (key {key_index+1})...")
        r = requests.post(
            f"https://api.apify.com/v2/acts/{actor_id}/runs?token={key}",
            json=payload,
            timeout=30
        )
        
        if r.status_code != 201:
            print(f"  ⚠️  Status {r.status_code}")
            return []
        
        run_id = r.json()["data"]["id"]
        print(f"  Task ID: {run_id}")
        
        # Wait for completion
        for attempt in range(60):
            time.sleep(2)
            r = requests.get(
                f"https://api.apify.com/v2/acts/{actor_id}/runs/{run_id}?token={key}",
                timeout=10
            )
            
            status = r.json()["data"]["status"]
            if status in ["SUCCEEDED", "FAILED"]:
                print(f"  Status: {status}")
                break
        
        # Get dataset
        dataset_id = r.json()["data"].get("defaultDatasetId", "")
        if not dataset_id:
            print(f"  No dataset")
            return []
        
        r = requests.get(
            f"https://api.apify.com/v2/datasets/{dataset_id}/items?token={key}&format=json",
            timeout=10
        )
        
        items = r.json() if isinstance(r.json(), list) else []
        listings = [i for i in items if isinstance(i, dict) and not i.get("#error") and i.get("title") and i.get("url")]
        
        print(f"  Got {len(listings)} listings")
        return listings
    
    except Exception as e:
        print(f"  Error: {e}")
        return []

def get_existing_urls():
    """Load existing URLs from sheet"""
    try:
        creds = Credentials.from_authorized_user_info(GOOGLE_OAUTH_TOKEN)
        creds.refresh(Request())
        gc = gspread.authorize(creds)
        
        ws = gc.open_by_key(SHEET_ID).worksheet(TARGET_SHEET)
        rows = ws.get_all_values()
        
        urls = set()
        for row in rows[1:]:  # Skip header
            if len(row) > 6 and row[6]:  # source_url is column 6
                urls.add(row[6].strip())
        
        print(f"✓ Loaded {len(urls)} existing URLs")
        return urls
    except Exception as e:
        print(f"Error loading URLs: {e}")
        return set()

def add_to_sheet(listings, source):
    """Add properly formatted rows to sheet"""
    if not listings:
        return 0
    
    try:
        creds = Credentials.from_authorized_user_info(GOOGLE_OAUTH_TOKEN)
        creds.refresh(Request())
        gc = gspread.authorize(creds)
        
        ws = gc.open_by_key(SHEET_ID).worksheet(TARGET_SHEET)
        
        # Build rows with correct column structure:
        # 0:Publish, 1:listing_id, 2:created_at, 3:updated_at, 4:is_active, 5:source_site, 
        # 6:source_url, 7:source_listing_key, 8:listed_by, 9:listing_title, ...
        rows = []
        for l in listings:
            listing_id = l.get("url", "").split("/")[-1][:20] if l.get("url") else "unknown"
            
            row = [
                "FALSE",                          # 0: Publish
                listing_id,                       # 1: listing_id
                datetime.now().isoformat() + "Z", # 2: created_at
                "N/A",                            # 3: updated_at
                "TRUE",                           # 4: is_active
                source,                           # 5: source_site (BizBuySell/BusinessesForSale)
                l.get("url", ""),                 # 6: source_url
                listing_id,                       # 7: source_listing_key
                "",                               # 8: listed_by
                l.get("title", "")[:200],         # 9: listing_title
                "",                               # 10: company_name
                "",                               # 11: industry
                "",                               # 12: sub_industry
                "",                               # 13: industry_normalized
                "",                               # 14: keywords_normalized
                "",                               # 15: city
                "",                               # 16: region
                "Ontario",                        # 17: state_province
                "Canada",                         # 18: country
                "Ontario, Canada",                # 19: geo_normalized
                "",                               # 20: asking_price
                "",                               # 21: revenue
                "",                               # 22: ebitda
                "",                               # 23: sde_cash_flow
                "FALSE",                          # 24: financials_disclosed
                "FALSE",                          # 25: revenue_disclosed
                "FALSE",                          # 26: ebitda_disclosed
                "",                               # 27: employees
                "",                               # 28: established_year
                "",                               # 29: property_type
                "",                               # 30: is_work_from_home
                "",                               # 31: is_franchise
                "",                               # 32: is_business_opportunity
                "",                               # 33: is_low_cost
                "",                               # 34: is_distressed
                "",                               # 35: is_price_reduced
                "",                               # 36: is_owner_financed
                "",                               # 37: is_hidden_gem
                "",                               # 38: is_quick_sale
                "",                               # 39: management_type
                datetime.now().strftime("%Y-%m-%d"),  # 40: listing_date
                "",                               # 41: days_on_market
                "",                               # 42: listing_age_bucket
                "",                               # 43: summary
                "",                               # 44: deal_tags
                "Active",                         # 45: listing_status
                "",                               # 46: listing_dedupe_key
                "",                               # 47: manual_review_flag
                "",                               # 48: deal_summary
                "",                               # 49: dealio_id
            ]
            rows.append(row)
        
        if rows:
            ws.append_rows(rows)
            print(f"  ✓ Added {len(rows)} rows")
            return len(rows)
        
        return 0
    except Exception as e:
        print(f"  Error adding rows: {e}")
        return 0

def send_email(stats):
    """Send results email"""
    total = sum(stats.values())
    body = f"""Listings Master Database — Weekly Scrape
==========================================

Run: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Results:
--------
BizBuySell: {stats.get('BizBuySell', 0)} listings added
BusinessesForSale: {stats.get('BusinessesForSale', 0)} listings added
Total: {total} new listings

Sheet: https://docs.google.com/spreadsheets/d/{SHEET_ID}/edit#gid=862653228

Status: ✓ Complete
"""
    
    try:
        proc = subprocess.Popen(["sendmail", "touhiduliet@gmail.com"], stdin=subprocess.PIPE, text=True)
        proc.communicate(input=f"Subject: Listings Master Database — Weekly Scrape\n\n{body}")
        print("✓ Email sent")
    except Exception as e:
        print(f"⚠️  Email: {e}")

def main():
    print("\n" + "=" * 70)
    print("Listings Master Database — Correct Format Scraper")
    print(f"Run: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    
    existing_urls = get_existing_urls()
    stats = {}
    
    for source, url in URLS.items():
        print(f"\n--- {source} ---")
        
        listings = scrape_with_apify(url, source)
        if not listings:
            print(f"  ⚠️  0 listings extracted")
            stats[source] = 0
            continue
        
        print(f"  ✓ Got {len(listings)} from API")
        
        # Filter duplicates
        new = [l for l in listings if l.get("url") not in existing_urls]
        print(f"  ✓ {len(new)} new (not in sheet)")
        
        added = add_to_sheet(new, source)
        stats[source] = added
        
        for l in new:
            existing_urls.add(l.get("url", ""))
    
    send_email(stats)
    
    total = sum(stats.values())
    print("\n" + "=" * 70)
    print(f"✓ Complete: {total} new listings added")
    for source, count in stats.items():
        print(f"  {source}: {count}")
    print("=" * 70 + "\n")

if __name__ == "__main__":
    main()
