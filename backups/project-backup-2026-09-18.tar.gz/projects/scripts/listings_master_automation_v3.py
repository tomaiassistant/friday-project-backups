#!/usr/bin/env python3
"""
Listings Master Database Automation v3
- Scrape BizBuySell & BusinessesForSale via TMCP (apify)
- Parse listings + push to Google Sheets via TMCP
- Deduplicate against existing data
Schedule: Mondays 3am
"""

import os, json, sys, time, re, subprocess
from datetime import datetime

# ============================================================================
# CONFIG
# ============================================================================
SHEET_ID = "13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148"
SHEET_NAME = "listings_master"
SHEET_ACCOUNT = "9a3d331a-0024-4eba-a618-417ad3463067"
APIFY_ACCOUNT = "aa4ca598-0b05-4ec5-97ce-514e36c3f76d"

URLS = {
    "businessesforsale": "https://canada.businessesforsale.com/canadian/search?CategoryIds=1299301&CategoryIds=1387201&CategoryIds=1316601&CategoryIds=1294601&CategoryIds=1294101&CategoryIds=1293501&CategoryIds=1389001&CategoryIds=1360201&CategoryIds=1293801&CategoryIds=1293901&CategoryIds=1293401&CategoryIds=1365401&RegionIds=1022301",
    "bizbuysell": "https://www.bizbuysell.com/ontario-canada-businesses-for-sale/?q=aTI9ODgsMTM2LDE0MSw4MSw4OSwyNywyMiwxMTgsMzEsNTcsMTE1LDE4OCwxLDIwLDMwLDIwNiw3OCwyMTMmbHQ9MzAsNDAsODA%3D"
}

LOG_FILE = "/tmp/listings_master_run.log"

# ============================================================================
# LOGGING
# ============================================================================
def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

# ============================================================================
# SHELL UTILITIES
# ============================================================================
def json_parse(text):
    """Safe JSON parse with fallback"""
    try:
        import json
        return json.loads(text)
    except:
        return {}

def shell_quote(s):
    """Quote shell arg"""
    import shlex
    return shlex.quote(s)

def run_cmd(cmd, timeout=60):
    """Run shell cmd, return (stdout, returncode)"""
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return result.stdout, result.returncode
    except Exception as e:
        log(f"Cmd error: {e}")
        return "", 1

# ============================================================================
# TMCP HELPERS
# ============================================================================
def tmcp_scrape(url, account_id):
    """Scrape URL via TMCP apify"""
    input_json = json.dumps({
        "actorId": "apify/web-scraper",
        "input": {
            "startUrls": [{"url": url}],
            "useChrome": True,
            "maxPagesPerCrawl": 1
        }
    })
    
    cmd = f"hermes mcp execute tmcp --account-id={account_id} --tool=apify --action=run_actor --input={shell_quote(input_json)} 2>&1"
    stdout, rc = run_cmd(cmd, timeout=90)
    
    if rc != 0:
        log(f"  Scrape failed: {url[:60]}")
        return None
    
    data = json_parse(stdout)
    # Apify returns dataset items
    items = data.get("items", [])
    if items:
        return items[0].get("html", "")
    return None

# ============================================================================
# PARSE HTML
# ============================================================================
def extract_urls(html, platform):
    """Extract listing URLs from search results"""
    try:
        from bs4 import BeautifulSoup
    except:
        log(f"  BeautifulSoup not available, skipping {platform}")
        return []
    
    listings = []
    try:
        soup = BeautifulSoup(html, 'html.parser')
        
        if platform == "businessesforsale":
            # Look for business cards
            for link in soup.find_all('a', href=re.compile('/canadian/')):
                href = link.get('href', '')
                title = link.get_text(strip=True)[:80]
                if href and title and 'business' in href.lower():
                    url = href if href.startswith('http') else f"https://canada.businessesforsale.com{href}"
                    listings.append({"url": url, "title": title})
        
        elif platform == "bizbuysell":
            # Look for business listings
            for link in soup.find_all('a', href=re.compile('/.*-for-sale')):
                href = link.get('href', '')
                title = link.get_text(strip=True)[:80]
                if href and title:
                    url = href if href.startswith('http') else f"https://www.bizbuysell.com{href}"
                    listings.append({"url": url, "title": title})
    
    except Exception as e:
        log(f"  Parse error: {e}")
    
    return listings

# ============================================================================
# DEDUPLICATE
# ============================================================================
def get_existing_urls():
    """Fetch column A (URLs) from existing sheet"""
    log("  Reading sheet for dedup...")
    
    input_json = json.dumps({
        "spreadsheetId": SHEET_ID,
        "ranges": [f"{SHEET_NAME}!A:A"]
    })
    
    cmd = f"hermes mcp execute tmcp --account-id={SHEET_ACCOUNT} --tool=sheets --action=read --input={shell_quote(input_json)} 2>&1"
    stdout, rc = run_cmd(cmd, timeout=30)
    
    urls = set()
    if rc == 0:
        data = json_parse(stdout)
        try:
            sheets = data.get("sheets", [])
            if sheets and sheets[0].get("data"):
                rows = sheets[0]["data"][0].get("rowData", [])
                for row in rows:
                    if row.get("values"):
                        cell_val = row["values"][0].get("formattedValue", "").strip()
                        if cell_val.startswith("http"):
                            urls.add(cell_val)
        except:
            pass
    
    log(f"    Found {len(urls)} existing URLs")
    return urls

# ============================================================================
# EXTRACT LISTING DATA
# ============================================================================
def extract_listing_info(html, url):
    """Extract key info from listing page"""
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, 'html.parser')
        
        # Title
        title_elem = soup.find('h1')
        title = title_elem.get_text(strip=True)[:100] if title_elem else "N/A"
        
        # Price
        price = "N/A"
        price_match = re.search(r'\$[\d,]+(?:\.\d{2})?', html)
        if price_match:
            price = price_match.group(0)
        
        # Location - try common patterns
        location = "N/A"
        for pattern in [r'Location:?\s*([^<\n]+)', r'City:?\s*([^<\n]+)', r'Province:?\s*([^<\n]+)']:
            match = re.search(pattern, html, re.IGNORECASE)
            if match:
                location = match.group(1).strip()[:50]
                break
        
        # Description
        desc = "N/A"
        desc_elem = soup.find('div', {'class': re.compile('description|summary|details', re.I)})
        if desc_elem:
            desc = desc_elem.get_text(strip=True)[:200]
        
        return [url, title, price, location, desc]
    
    except Exception as e:
        log(f"    Extract error: {e}")
        return None

# ============================================================================
# PUSH TO SHEET
# ============================================================================
def append_rows(rows):
    """Append rows to Google Sheet"""
    if not rows:
        log("  No rows to append")
        return 0
    
    log(f"  Appending {len(rows)} rows to sheet...")
    
    input_json = json.dumps({
        "spreadsheetId": SHEET_ID,
        "range": f"{SHEET_NAME}!A:E",
        "values": rows
    })
    
    cmd = f"hermes mcp execute tmcp --account-id={SHEET_ACCOUNT} --tool=sheets --action=write --input={shell_quote(input_json)} 2>&1"
    stdout, rc = run_cmd(cmd, timeout=30)
    
    if rc == 0:
        log(f"    ✓ Added {len(rows)} rows")
        return len(rows)
    else:
        log(f"    ✗ Write failed")
        return 0

# ============================================================================
# MAIN
# ============================================================================
def main():
    log("=" * 80)
    log("LISTINGS MASTER DATABASE AUTOMATION")
    log("=" * 80)
    
    try:
        existing_urls = get_existing_urls()
        new_rows = []
        processed = 0
        
        for platform, search_url in URLS.items():
            log(f"\n[{platform.upper()}]")
            log(f"  Scraping: {search_url[:70]}...")
            
            # Scrape search results
            search_html = tmcp_scrape(search_url, APIFY_ACCOUNT)
            if not search_html:
                log(f"  ✗ Scrape failed, skipping")
                continue
            
            # Extract listing URLs
            listings = extract_urls(search_html, platform)
            log(f"  Found {len(listings)} listings")
            
            # Process each listing (limit 10 per platform)
            for i, listing in enumerate(listings[:10], 1):
                url = listing["url"]
                title = listing["title"]
                
                # Check duplicate
                if url in existing_urls:
                    log(f"  [{i}] SKIP (dup): {title[:50]}")
                    continue
                
                # Fetch full listing
                log(f"  [{i}] Fetching: {title[:50]}...")
                listing_html = tmcp_scrape(url, APIFY_ACCOUNT)
                if not listing_html:
                    log(f"       ✗ Failed to fetch")
                    continue
                
                # Extract info
                row = extract_listing_info(listing_html, url)
                if row:
                    new_rows.append(row)
                    processed += 1
                    log(f"       ✓ Parsed: {row[1][:50]}")
                
                time.sleep(1)  # Rate limit
        
        # Push to sheet
        added = append_rows(new_rows)
        
        log("\n" + "=" * 80)
        log(f"✓ Complete: Processed {processed}, Added {added} rows")
        log("=" * 80)
        return 0
    
    except Exception as e:
        log(f"✗ ERROR: {e}")
        import traceback
        log(traceback.format_exc())
        return 1

if __name__ == "__main__":
    sys.exit(main())
