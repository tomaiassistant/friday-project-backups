#!/usr/bin/env bash
set -euo pipefail

SRC="/root/projects"
BACKUP_REPO="/root/projects-backup/friday-project-backups"
ASKPASS="/root/.hermes/scripts/github-askpass-friday.sh"
DATE="$(date -u +%F)"
ARCHIVE="project-backup-${DATE}.tar.gz"

cd "$BACKUP_REPO"
mkdir -p backups

tar \
  --exclude='*/.git' \
  --exclude='*/.venv' \
  --exclude='*/node_modules' \
  --exclude='*/__pycache__' \
  -czf "backups/${ARCHIVE}" -C /root projects

# Keep last 14 project backup archives in the repo.
ls -1t backups/project-backup-*.tar.gz 2>/dev/null | tail -n +15 | xargs -r rm -f

if ! git diff --quiet || [ -n "$(git ls-files --others --exclude-standard)" ]; then
  git add -A
  git commit -m "chore: daily projects backup ${DATE}"
fi

GIT_ASKPASS="$ASKPASS" GIT_TERMINAL_PROMPT=0 git push origin main

echo "Projects backup pushed: ${ARCHIVE}"
