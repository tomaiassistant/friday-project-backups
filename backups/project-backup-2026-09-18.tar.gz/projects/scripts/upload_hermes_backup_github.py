#!/usr/bin/env python3
import datetime as dt
import json
import os
import subprocess
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

OWNER = "tomaiassistant"
REPO = "friday-project-backups"
ASKPASS = "/root/.hermes/scripts/github-askpass-friday.sh"
HERMES_HOME = Path("/root/.hermes")
OUT_DIR = Path("/root/backups/hermes")
OUT_DIR.mkdir(parents=True, exist_ok=True)

stamp = dt.datetime.utcnow().strftime("%Y-%m-%d")
zip_path = OUT_DIR / f"hermes-backup-{stamp}.zip"

# EXCLUSIONS: Keep zip small
exclude_first_parts = {"logs", "audio_cache", "cache", "tmp", "tmp_logs"}

with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    for path in HERMES_HOME.rglob("*"):
        if not path.is_file():
            continue
        rel_to_home = path.relative_to(HERMES_HOME)
        if rel_to_home.parts and rel_to_home.parts[0] in exclude_first_parts:
            continue
        zf.write(path, Path(".hermes") / rel_to_home)

# Keep only last 7 local archives
archives = sorted(OUT_DIR.glob("hermes-backup-*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
for old in archives[7:]:
    old.unlink(missing_ok=True)

token = subprocess.check_output([ASKPASS, "Password for github"], text=True).strip()
api = f"https://api.github.com/repos/{OWNER}/{REPO}"
headers = {
    "Authorization": "Bearer " + token,
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
}

def request(method, url, data=None, extra_headers=None):
    body = data
    if isinstance(data, (dict, list)):
        body = json.dumps(data).encode()
    req = urllib.request.Request(url, data=body, method=method, headers={**headers, **(extra_headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=300) as resp:
            raw = resp.read().decode(errors="replace")
            return resp.status, json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode(errors="replace")
        try:
            parsed = json.loads(raw)
        except Exception:
            parsed = {"raw": raw[:500]}
        if exc.code == 404:
            return exc.code, parsed
        raise RuntimeError(f"{method} {url} failed {exc.code}: {parsed}")

tag = f"hermes-backup-{stamp}"
status, release = request("GET", f"{api}/releases/tags/{tag}")
if status == 404:
    _, release = request("POST", f"{api}/releases", {
        "tag_name": tag,
        "name": f"Hermes Backup {stamp}",
        "body": "Daily Friday Hermes backup. Contains sensitive .hermes state; keep this repository private.",
        "draft": False,
        "prerelease": False,
    }, {"Content-Type": "application/json"})

asset_name = zip_path.name
for asset in release.get("assets", []):
    if asset.get("name") == asset_name:
        request("DELETE", f"{api}/releases/assets/{asset['id']}")

upload_url = release["upload_url"].split("{")[0] + "?" + urllib.parse.urlencode({"name": asset_name})

# Stream the file instead of loading into memory
def stream_file(path):
    with open(path, "rb") as f:
        while True:
            chunk = f.read(65536) # 64KB chunks
            if not chunk:
                break
            yield chunk

req = urllib.request.Request(upload_url, data=stream_file(zip_path), method="POST", headers={"Content-Type": "application/zip"})
with urllib.request.urlopen(req, timeout=600) as resp:
    _ = resp.read()

print(f"Backup created and streamed of Hermes ({zip_path.name})")
