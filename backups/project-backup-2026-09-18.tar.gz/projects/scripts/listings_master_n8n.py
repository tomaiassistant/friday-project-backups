#!/usr/bin/env python3
"""
Listings Master Database - n8n Workflow Integration
Triggers n8n workflows via webhook, waits for completion, processes output
"""

import json
import gspread
import requests
import time
from datetime import datetime
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials

# Config
GOOGLE_OAUTH_TOKEN = {
    "token": "ya29.a0AT3oNZ-JW_7EcYKUWaIZKZdStO074Ke4ssKwy9NUiYW-7GZmcdieSHOK17ZDM2Nn-6hlOFkDhEFQ84ii9II5b40R8Lcv4I-4easnsR6HNbDDfCvrZsuqYuGRpekGrDAtMpYZkkuFYDy9mTFEiRO5531B_9DbaVg9ExiENYSiWlqmU5rQVJoBKFmeDYkn50fk1pKn65rsaCgYKAVMSARESFQHGX2Mi_6x5Y7Q6SJLMb6PBOgqJjQ0207",
    "refresh_token": "1//0gTCbf_lOFNEiCgYIARAAGBASNwF-L9IrC0-1Ei4F_RlCfukXzLQnzf4_AhB1Lotaz3hKMXZQTYqWO5r8mh1oasZJyd6RxV3Gq2A",
    "token_uri": "https://oauth2.googleapis.com/token",
    "client_id": "902478705286-ls0579voqir3hd8fue7mks9hjl0gm845.apps.googleusercontent.com",
    "client_secret": "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",
    "type": "authorized_user"
}

SHEET_ID = "13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148"
TARGET_SHEET = "listings_master"
EMAIL_TO = "touhiduliet@gmail.com"

# n8n Webhook URLs - REPLACE WITH YOUR ACTUAL WEBHOOKS
N8N_WEBHOOKS = {
    "BizBuySell": "https://YOUR_N8N_INSTANCE.com/webhook/bizbuy-sell-trigger",
    "BusinessesForSale": "https://YOUR_N8N_INSTANCE.com/webhook/businessesforsale-trigger"
}

# Webhook to receive workflow output (set up n8n to POST back here)
OUTPUT_WEBHOOK_URL = "http://localhost:3000/webhook/listings-output"

def trigger_n8n_workflow(source, webhook_url):
    """Trigger n8n workflow and get execution ID"""
    print(f"\n[*] Triggering n8n workflow: {source}...")
    
    try:
        payload = {
            "source": source,
            "timestamp": datetime.now().isoformat(),
            "wait_for_output": True
        }
        
        response = requests.post(webhook_url, json=payload, timeout=30)
        
        if response.status_code in [200, 201]:
            data = response.json()
            execution_id = data.get("execution_id") or data.get("workflowId")
            print(f"  ✓ Triggered (ID: {execution_id})")
            return execution_id
        else:
            print(f"  ❌ Error: {response.status_code}")
            return None
    except Exception as e:
        print(f"  ❌ Error: {e}")
        return None

def wait_for_workflow_output(execution_id, timeout=600):
    """Wait for n8n workflow to complete and return output"""
    print(f"  ⏳ Waiting for workflow output (timeout: {timeout}s)...")
    
    start = time.time()
    while time.time() - start < timeout:
        # Check if output file exists (n8n writes results to disk/temp)
        output_file = f"/tmp/n8n_output_{execution_id}.json"
        try:
            with open(output_file, "r") as f:
                output = json.load(f)
                print(f"  ✓ Output received ({len(output)} items)")
                return output
        except FileNotFoundError:
            pass
        
        time.sleep(5)
    
    print(f"  ⚠️  Timeout waiting for output")
    return None

def get_existing_urls():
    """Load existing URLs from sheet"""
    try:
        creds = Credentials.from_authorized_user_info(GOOGLE_OAUTH_TOKEN)
        creds.refresh(Request())
        gc = gspread.authorize(creds)
        
        ws = gc.open_by_key(SHEET_ID).worksheet(TARGET_SHEET)
        rows = ws.get_all_values()
        
        urls = set()
        for row in rows[1:]:
            if len(row) > 6 and row[6]:
                urls.add(row[6].strip())
        
        print(f"✓ Loaded {len(urls)} existing URLs")
        return urls
    except Exception as e:
        print(f"❌ Error: {e}")
        return set()

def add_to_sheet(listings):
    """Add listings to sheet"""
    if not listings:
        return 0
    
    try:
        creds = Credentials.from_authorized_user_info(GOOGLE_OAUTH_TOKEN)
        creds.refresh(Request())
        gc = gspread.authorize(creds)
        
        ws = gc.open_by_key(SHEET_ID).worksheet(TARGET_SHEET)
        
        rows = []
        for listing in listings:
            # Assuming listing dict has: title, url, source, price, etc.
            listing_id = listing.get("url", "").split("/")[-2] if listing.get("url") else "unknown"
            
            row = [
                "FALSE",                              # Publish
                listing_id,                           # listing_id
                datetime.now().isoformat() + "Z",     # created_at
                "N/A",                                # updated_at
                "TRUE",                               # is_active
                listing.get("source", ""),            # source_site
                listing.get("url", ""),               # source_url
                listing_id,                           # source_listing_key
                listing.get("listed_by", ""),         # listed_by
                listing.get("title", "")[:200],       # listing_title
                listing.get("company", ""),           # company_name
                listing.get("industry", ""),          # industry
                "",                                   # sub_industry
                "",                                   # industry_normalized
                listing.get("keywords", ""),          # keywords_normalized
                listing.get("city", ""),              # city
                listing.get("region", ""),            # region
                "Ontario",                            # state_province
                "Canada",                             # country
                "Ontario, Canada",                    # geo_normalized
                listing.get("price", ""),             # asking_price
                listing.get("revenue", ""),           # revenue
                listing.get("ebitda", ""),            # ebitda
                "",                                   # sde_cash_flow
                "FALSE",                              # financials_disclosed
                "FALSE",                              # revenue_disclosed
                "FALSE",                              # ebitda_disclosed
                listing.get("employees", ""),         # employees
                listing.get("established_year", ""),  # established_year
                listing.get("property_type", ""),     # property_type
                "",                                   # is_work_from_home
                "",                                   # is_franchise
                "",                                   # is_business_opportunity
                "",                                   # is_low_cost
                "",                                   # is_distressed
                "",                                   # is_price_reduced
                "",                                   # is_owner_financed
                "",                                   # is_hidden_gem
                "",                                   # is_quick_sale
                "",                                   # management_type
                datetime.now().strftime("%Y-%m-%d"), # listing_date
                "",                                   # days_on_market
                "",                                   # listing_age_bucket
                listing.get("summary", ""),           # summary
                listing.get("tags", ""),              # deal_tags
                "Active",                             # listing_status
                "",                                   # listing_dedupe_key
                "",                                   # manual_review_flag
                listing.get("deal_summary", ""),      # deal_summary
                "",                                   # dealio_id
                "",                                   # Buyers -->
                "",                                   # Mario N
                "",                                   # jacob
                "",                                   # Sunny
            ]
            rows.append(row)
        
        if rows:
            ws.append_rows(rows)
            print(f"✓ Added {len(rows)} rows to sheet")
            return len(rows)
        
        return 0
    except Exception as e:
        print(f"❌ Error: {e}")
        return 0

def main():
    print("\n" + "=" * 70)
    print("LISTINGS MASTER DATABASE - n8n Workflow Integration")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print("=" * 70)
    
    # Get existing
    existing_urls = get_existing_urls()
    
    stats = {}
    all_new = []
    
    # Trigger both workflows
    for source, webhook_url in N8N_WEBHOOKS.items():
        exec_id = trigger_n8n_workflow(source, webhook_url)
        
        if not exec_id:
            print(f"  ⚠️  {source} failed to trigger")
            stats[source] = 0
            continue
        
        # Wait for output
        output = wait_for_workflow_output(exec_id)
        
        if not output:
            print(f"  ⚠️  {source} returned no data")
            stats[source] = 0
            continue
        
        # Process output
        new_listings = []
        for item in output:
            if item.get("url") not in existing_urls:
                new_listings.append(item)
                existing_urls.add(item.get("url"))
        
        print(f"  → {len(new_listings)} new listings from {source}")
        stats[source] = len(new_listings)
        all_new.extend(new_listings)
    
    # Add to sheet
    total_added = 0
    if all_new:
        total_added = add_to_sheet(all_new)
    
    # Summary
    print("\n" + "=" * 70)
    print(f"✓ COMPLETE: {total_added} new listings added")
    for source, count in stats.items():
        print(f"  {source}: {count}")
    print(f"Sheet: {SHEET_ID}")
    print("=" * 70 + "\n")

if __name__ == "__main__":
    main()
