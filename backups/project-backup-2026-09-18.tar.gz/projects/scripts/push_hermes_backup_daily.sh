#!/usr/bin/env bash
set -euo pipefail

HERMES_HOME="/root/.hermes"
BACKUP_REPO="/root/projects-backup/friday-project-backups"
ASKPASS="/root/.hermes/scripts/github-askpass-friday.sh"
DATE="$(date -u +%F)"
ARCHIVE="hermes-backup-${DATE}.tar.gz"
TMP_DIR="/tmp/hermes-backup-${DATE}"

cd "$BACKUP_REPO"
mkdir -p backups

# Copy .hermes to temp location to avoid "file changed as we read it"
rm -rf "$TMP_DIR"
cp -r "$HERMES_HOME" "$TMP_DIR" 2>/dev/null || true

# Remove excluded directories from temp copy
rm -rf "$TMP_DIR"/logs "$TMP_DIR"/audio_cache "$TMP_DIR"/cache "$TMP_DIR"/tmp "$TMP_DIR"/tmp_logs "$TMP_DIR"/node "$TMP_DIR"/lsp "$TMP_DIR"/.git 2>/dev/null || true
find "$TMP_DIR" -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find "$TMP_DIR" -name "*.pyc" -delete 2>/dev/null || true
# Remove SQLite temp files if they exist
rm -f "$TMP_DIR"/kanban.db-wal "$TMP_DIR"/kanban.db-shm 2>/dev/null || true

# Create tar.gz from temp copy
tar -czf "backups/${ARCHIVE}" -C "$TMP_DIR" . 2>/dev/null

# Cleanup
rm -rf "$TMP_DIR"

# Keep last 14 hermes backup archives in the repo.
ls -1t backups/hermes-backup-*.tar.gz 2>/dev/null | tail -n +15 | xargs -r rm -f

if ! git diff --quiet || [ -n "$(git ls-files --others --exclude-standard)" ]; then
  git add -A
  git commit -m "chore: daily Hermes backup ${DATE}"
fi

GIT_ASKPASS="$ASKPASS" GIT_TERMINAL_PROMPT=0 git push origin main

echo "Hermes backup pushed: ${ARCHIVE}"
