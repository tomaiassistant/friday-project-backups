#!/usr/bin/env python3
"""
Listings Master Database Automation — Production
Browser-based scraping with email report
Uses execute_code for tool access
"""
import json
from datetime import datetime

prompt = """
Run the Listings Master Database weekly automation:

1. Scrape BizBuySell Ontario listings (apply filters, get latest)
2. Scrape BusinessesForSale Canada listings (apply filters)
3. Parse HTML to extract: title, price, URL, location
4. Deduplicate against current sheet
5. Add new listings to Google Sheet
6. Send email report to touhiduliet@gmail.com with:
   - Count from BizBuySell
   - Count from BusinessesForSale
   - Total added
   - Run timestamp

Filter URLs:
- BizBuySell: https://www.bizbuysell.com/ontario-canada-businesses-for-sale/?q=aTI9ODgsMTM2LDE0MSw4MSw4OSwyNywyMiwxMTgsMzEsNTcsMTE1LDE4OCwxLDIwLDMwLDIwNiw3OCwyMTMmbHQ9MzAsNDAsODA%3D
- BusinessesForSale: https://canada.businessesforsale.com/canadian/search?CategoryIds=1299301&CategoryIds=1387201&CategoryIds=1316601&CategoryIds=1294601&CategoryIds=1294101&CategoryIds=1293501&CategoryIds=1389001&CategoryIds=1360201&CategoryIds=1293801&CategoryIds=1293901&CategoryIds=1293401&CategoryIds=1365401&RegionIds=1022301

Output format:
- Print each step
- Final summary: BizBuySell: X | BusinessesForSale: Y | Total: Z
- Confirm email sent

CRITICAL:
- Get actual data from pages (no placeholders)
- Click into each listing to get full details
- Verify prices, titles, URLs are real
- Only add if NOT already in sheet
- Send real email on completion
"""

print(prompt)
