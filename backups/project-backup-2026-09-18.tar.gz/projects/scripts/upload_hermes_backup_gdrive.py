#!/usr/bin/env python3
import datetime as dt
import json
import os
import requests
import zipfile
import base64
from pathlib import Path

# Config
TMCP_API_KEY = os.getenv("TMCP_API_KEY")
TMCP_BASE_URL = os.getenv("TMCP_BASE_URL")
DRIVE_ACCOUNT_ID = "e913a029-1f3d-4e3b-a34e-bb9f7cd26aeb"
FOLDER_ID = "1KhUF4agzo1XAWH7L6BSZUHXNG1IKsb46"
HERMES_HOME = Path("/root/.hermes")
OUT_DIR = Path("/root/backups/hermes")
OUT_DIR.mkdir(parents=True, exist_ok=True)

if not TMCP_API_KEY or not TMCP_BASE_URL:
    print("Error: TMCP_API_KEY or TMCP_BASE_URL not set")
    exit(1)

stamp = dt.datetime.utcnow().strftime("%Y-%m-%d")
zip_path = OUT_DIR / f"hermes-backup-{stamp}.zip"
exclude_first_parts = {"logs", "audio_cache", "cache", "tmp", "tmp_logs"}

print(f"Zipping .hermes... (excluding {exclude_first_parts})")
with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    for path in HERMES_HOME.rglob("*"):
        if not path.is_file():
            continue
        rel_to_home = path.relative_to(HERMES_HOME)
        if rel_to_home.parts and rel_to_home.parts[0] in exclude_first_parts:
            continue
        zf.write(path, Path(".hermes") / rel_to_home)
print(f"Zip created: {zip_path.name}")

# Base64 encode the zip file to make it JSON serializable
print("Encoding file to Base64...")
with open(zip_path, "rb") as f:
    encoded_file = base64.b64encode(f.read()).decode('utf-8')

payload = {
    "tool": "drive",
    "action": "drive.upload",
    "input": {
        "file": encoded_file,
        "filename": zip_path.name,
        "folder_id": FOLDER_ID
    },
    "account_id": DRIVE_ACCOUNT_ID
}

headers = {
    "Authorization": f"Bearer {TMCP_API_KEY}",
    "Content-Type": "application/json"
}

print("Uploading to TMCP Gateway...")
response = requests.post(f"{TMCP_BASE_URL}/execute", json=payload, headers=headers, timeout=600)

if response.ok:
    print(f"✓ SUCCESS: Backup uploaded to Google Drive: {zip_path.name}")
else:
    print(f"✗ FAILED: {response.status_code} - {response.text}")
