#!/bin/bash
# Disk cleanup script for VPS - safe for Hermes, AApanel, OpenClark
set -euo pipefail

echo "[$(date)] Starting disk cleanup..."

# 1. Snap pruning - keep only 2 revisions
snap set system refresh.retain=2 2>/dev/null || true
snap list --all | awk '/disabled/{print $1, $3}' | while read -r snapname revision; do
    echo "Removing disabled snap: ${snapname} rev${revision}"
    snap remove "$snapname" --revision="$revision" 2>/dev/null || true
done

# 2. APT cache cleanup
apt-get clean -y
apt-get autoremove -y --purge

# 3. Journal logs - keep 3 days
journalctl --vacuum-time=3d

# 4. Truncate btmp if large
if [ -f /var/log/btmp ] && [ $(stat -c%s /var/log/btmp) -gt $((10*1024*1024)) ]; then
    echo "Truncating /var/log/btmp"
    truncate -s 0 /var/log/btmp
fi

# 5. Docker system prune - keep running containers
if command -v docker >/dev/null 2>&1; then
    echo "Pruning Docker system (images, containers, volumes, build cache)..."
    docker system prune -af --volumes
fi

# 6. Clear Go pkg cache (safe to delete)
if [ -d "/root/go/pkg" ]; then
    echo "Clearing Go pkg cache..."
    rm -rf /root/go/pkg/*
fi

# 7. Remove Python virtual envs in projects (they can be reinstalled)
for proj in ListingsFinder-AI brain-model; do
    if [ -d "/root/projects/${proj}/.venv" ]; then
        echo "Removing .venv for ${proj}..."
        rm -rf "/root/projects/${proj}/.venv"
    fi
done

# 8. Clear user caches
echo "Clearing user caches..."
rm -rf /root/.cache/* /root/.npm/* 2>/dev/null || true

# 9. Keep only latest Hermes backup, delete older ones
BACKUP_DIR="/root/backups/hermes"
if [ -d "$BACKUP_DIR" ]; then
    # Keep the most recent .zip file, delete others
    echo "Cleaning old Hermes backups..."
    ls -1t "$BACKUP_DIR"/*.zip 2>/dev/null | tail -n +2 | while read -r oldbackup; do
        echo "Removing old backup: $oldbackup"
        rm -f "$oldbackup"
    done
fi

echo "[$(date)] Disk cleanup finished."