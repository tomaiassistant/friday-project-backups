#!/usr/bin/env python3
"""
Listings Master Database Automation — Geekflare Web Scraping + Google Sheets
Scrapes BizBuySell + BusinessesForSale, deduplicates, adds to Google Sheets
"""

import os
import sys
import json
import re
import time
from datetime import datetime
from urllib.parse import urljoin
import requests
from bs4 import BeautifulSoup

try:
    import gspread
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
except ImportError:
    print("Installing dependencies...")
    os.system("pip install gspread google-auth google-auth-oauthlib beautifulsoup4 -q")
    import gspread
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials

# ============================================================================
# LOAD CONFIG
# ============================================================================

script_dir = os.path.dirname(os.path.abspath(__file__))
config_path = os.path.join(script_dir, ".listings_config.json")

with open(config_path, "r") as f:
    CONFIG = json.load(f)

GEEKFLARE_API_KEY = CONFIG["GEEKFLARE_API_KEY"]
GEEKFLARE_API_URL = "https://api.geekflare.com/webscraping"
GOOGLE_SHEET_ID = CONFIG["GOOGLE_SHEET_ID"]
SHEET_NAME = "listings_master"
GOOGLE_OAUTH_TOKEN = CONFIG["GOOGLE_OAUTH_TOKEN"]
RESEND_API_KEY = CONFIG["RESEND_API_KEY"]
RESEND_FROM = CONFIG["RESEND_FROM"]
RESEND_TO = CONFIG["RESEND_TO"]

SCRAPE_URLS = {
    "bizbuy": "https://www.bizbuysell.com/ontario-canada-businesses-for-sale/?q=aTI9ODgsMTM2LDE0MSw4MSw4OSwyNywyMiwxMTgsMzEsNTcsMTE1LDE4OCwxLDIwLDMwLDIwNiw3OCwyMTMmbHQ9MzAsNDAsODA%3D",
    "businessforsale": "https://canada.businessesforsale.com/canadian/search?CategoryIds=1299301&CategoryIds=1387201&CategoryIds=1316601&CategoryIds=1294601&CategoryIds=1294101&CategoryIds=1293501&CategoryIds=1389001&CategoryIds=1360201&CategoryIds=1293801&CategoryIds=1293901&CategoryIds=1293401&CategoryIds=1365401&RegionIds=1022301"
}

# ============================================================================
# FUNCTIONS
# ============================================================================

def geekflare_scrape(url):
    """Scrape URL with Geekflare API"""
    headers = {"x-api-key": GEEKFLARE_API_KEY}
    payload = {
        "url": url,
        "format": "html"
    }
    try:
        resp = requests.post(GEEKFLARE_API_URL, json=payload, headers=headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        if data.get("apiStatus") == "success":
            return data.get("data", {}).get("html", "")
        else:
            print(f"  ❌ Geekflare error: {data.get('message')}")
            return None
    except Exception as e:
        print(f"  ❌ Request failed: {e}")
        return None

def scrape_bizbuy_listings(html):
    """Extract listing URLs from BizBuySell"""
    if not html:
        return []
    soup = BeautifulSoup(html, "html.parser")
    listings = []
    
    # Find all links that contain business listings
    for link in soup.find_all("a", href=True):
        href = link.get("href", "")
        if "/business-for-sale/" in href:
            title = link.text.strip()[:100]
            if title:
                listings.append({
                    "source": "BizBuySell",
                    "url": urljoin("https://www.bizbuysell.com", href),
                    "title": title
                })
    
    return listings

def scrape_businessforsale_listings(html):
    """Extract listing URLs from BusinessesForSale"""
    if not html:
        return []
    soup = BeautifulSoup(html, "html.parser")
    listings = []
    
    # Find all links containing business listings
    for link in soup.find_all("a", href=True):
        href = link.get("href", "")
        if "/listing/" in href or "/details/" in href:
            title = link.text.strip()[:100]
            if title:
                listings.append({
                    "source": "BusinessesForSale",
                    "url": urljoin("https://canada.businessesforsale.com", href),
                    "title": title
                })
    
    return listings

def get_existing_urls(sheet):
    """Get all existing URLs from sheet to deduplicate"""
    try:
        worksheet = sheet.worksheet(SHEET_NAME)
        data = worksheet.get_all_values()
        urls = set()
        for row in data[1:]:  # Skip header
            if row and len(row) > 3:
                urls.add(row[3].strip())
        return urls
    except Exception as e:
        print(f"  ⚠️  Error reading sheet: {e}")
        return set()

def add_to_sheet(sheet, listings):
    """Add new listings to Google Sheet"""
    if not listings:
        return 0
    
    try:
        worksheet = sheet.worksheet(SHEET_NAME)
        existing_urls = get_existing_urls(sheet)
        
        rows_added = 0
        for listing in listings:
            if listing["url"] not in existing_urls:
                row = [
                    listing["source"],
                    listing.get("title", "N/A"),
                    listing.get("price", "N/A"),
                    listing["url"],
                    listing.get("location", "N/A"),
                    datetime.now().strftime("%Y-%m-%d")
                ]
                worksheet.append_row(row)
                rows_added += 1
                existing_urls.add(listing["url"])
        
        return rows_added
    except Exception as e:
        print(f"  ❌ Error adding to sheet: {e}")
        return 0

def send_email_report(bizbuy_count, businessforsale_count):
    """Send email report via Resend"""
    total = bizbuy_count + businessforsale_count
    subject = f"Listings Master Database — Weekly Scrape ({datetime.now().strftime('%Y-%m-%d')})"
    html_body = f"""
    <html>
      <body style="font-family: Arial, sans-serif; color: #333;">
        <h2>Listings Master Database — Weekly Scrape</h2>
        <p><strong>Run:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        
        <h3>Results:</h3>
        <ul>
          <li><strong>BizBuySell:</strong> {bizbuy_count} listings added</li>
          <li><strong>BusinessesForSale:</strong> {businessforsale_count} listings added</li>
          <li><strong>Total:</strong> {total} new listings</li>
        </ul>
        
        <p><strong>Sheet:</strong> <a href="https://docs.google.com/spreadsheets/d/13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148/edit">Listings Master Database</a></p>
        
        <p><strong>Status:</strong> ✓ Complete</p>
        <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
        <p style="font-size: 12px; color: #999;">Automated by Hermes — Listings Master Automation</p>
      </body>
    </html>
    """
    
    try:
        resp = requests.post(
            "https://api.resend.com/emails",
            headers={"Authorization": f"Bearer {RESEND_API_KEY}"},
            json={
                "from": RESEND_FROM,
                "to": RESEND_TO,
                "subject": subject,
                "html": html_body
            }
        )
        if resp.status_code == 200:
            print(f"✓ Email sent to {RESEND_TO}")
        else:
            print(f"❌ Email failed: {resp.status_code} - {resp.text[:100]}")
    except Exception as e:
        print(f"❌ Email error: {e}")

def authenticate_google_sheets():
    """Authenticate with Google Sheets API"""
    try:
        creds = Credentials.from_authorized_user_info(GOOGLE_OAUTH_TOKEN)
        if creds.expired:
            creds.refresh(Request())
        gc = gspread.authorize(creds)
        return gc.open_by_key(GOOGLE_SHEET_ID)
    except Exception as e:
        print(f"❌ Google auth failed: {e}")
        return None

# ============================================================================
# MAIN
# ============================================================================

def main():
    print("=" * 70)
    print("Listings Master Scraper | Geekflare API")
    print(f"Run: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    
    # Authenticate Google Sheets
    sheet = authenticate_google_sheets()
    if not sheet:
        print("❌ Failed to authenticate Google Sheets")
        sys.exit(1)
    
    bizbuy_count = 0
    businessforsale_count = 0
    
    # Scrape BizBuySell
    print("\n[1/2] BizBuySell (Ontario)")
    print(f"  Scraping: {SCRAPE_URLS['bizbuy'][:60]}...")
    html = geekflare_scrape(SCRAPE_URLS["bizbuy"])
    if html:
        listings = scrape_bizbuy_listings(html)
        print(f"  Found {len(listings)} potential listings")
        bizbuy_count = add_to_sheet(sheet, listings)
        print(f"  ✓ Added {bizbuy_count} NEW listings (deduplicated)")
    else:
        print(f"  ❌ Scrape failed")
    
    time.sleep(2)  # Rate limit
    
    # Scrape BusinessesForSale
    print("\n[2/2] BusinessesForSale (Canada)")
    print(f"  Scraping: {SCRAPE_URLS['businessforsale'][:60]}...")
    html = geekflare_scrape(SCRAPE_URLS["businessforsale"])
    if html:
        listings = scrape_businessforsale_listings(html)
        print(f"  Found {len(listings)} potential listings")
        businessforsale_count = add_to_sheet(sheet, listings)
        print(f"  ✓ Added {businessforsale_count} NEW listings (deduplicated)")
    else:
        print(f"  ❌ Scrape failed")
    
    # Send email report
    print("\n[3/3] Sending email report...")
    send_email_report(bizbuy_count, businessforsale_count)
    
    print("\n" + "=" * 70)
    print(f"Total new listings added: {bizbuy_count + businessforsale_count}")
    print("=" * 70)

if __name__ == "__main__":
    main()
