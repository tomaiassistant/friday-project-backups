#!/usr/bin/env python3
"""
Listings Master Database Automation — Production
Uses Hermes browser tool to scrape BizBuySell + BusinessesForSale
Sends email report with counts
"""
import os
import json
import time
import subprocess
from datetime import datetime

SHEET_ID = "13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148"
EMAIL_TO = "touhiduliet@gmail.com"
RESEND_KEY = "re_9AtYyDPh_KEz5LVymAyk6bwRWGNB1upq4"

BIZBUY_URL = "https://www.bizbuysell.com/ontario-canada-businesses-for-sale/?q=aTI9ODgsMTM2LDE0MSw4MSw4OSwyNywyMiwxMTgsMzEsNTcsMTE1LDE4OCwxLDIwLDMwLDIwNiw3OCwyMTMmbHQ9MzAsNDAsODA%3D"
BUSINESS_FOR_SALE_URL = "https://canada.businessesforsale.com/canadian/search?CategoryIds=1299301&CategoryIds=1387201&CategoryIds=1316601&CategoryIds=1294601&CategoryIds=1294101&CategoryIds=1293501&CategoryIds=1389001&CategoryIds=1360201&CategoryIds=1293801&CategoryIds=1293901&CategoryIds=1293401&CategoryIds=1365401&RegionIds=1022301"

def send_email(subject, body):
    """Send email via Resend"""
    try:
        cmd = [
            "curl", "-X", "POST", "https://api.resend.com/emails",
            "-H", f"Authorization: Bearer {RESEND_KEY}",
            "-H", "Content-Type: application/json",
            "-d", json.dumps({
                "from": "notifications@dealiomarketplace.com",
                "to": EMAIL_TO,
                "subject": subject,
                "html": body.replace("\n", "<br>")
            })
        ]
        subprocess.run(cmd, check=True, capture_output=True)
        print(f"✓ Email sent: {subject}")
    except Exception as e:
        print(f"✗ Email failed: {e}")

def scrape_site(url, source_name):
    """Scrape via Hermes browser tool"""
    print(f"\n[{source_name}] Scraping {url}")
    try:
        # Call browser_navigate and get HTML
        from hermes_tools import browser_navigate
        snap = browser_navigate(url)
        
        # Parse HTML
        from bs4 import BeautifulSoup
        html = snap.get('full_html', '')
        soup = BeautifulSoup(html, 'html.parser')
        
        listings = []
        # Extract based on source
        if 'bizbuysell' in url:
            items = soup.find_all('div', class_=lambda x: x and 'business' in x.lower())
        else:
            items = soup.find_all('div', class_=lambda x: x and ('listing' in x.lower() or 'business' in x.lower()))
        
        for item in items[:50]:  # limit to 50 per source
            try:
                link = item.find('a', href=True)
                title = item.find(['h2', 'h3', 'a'])
                if link and title:
                    listings.append({
                        'source': source_name,
                        'title': title.get_text(strip=True)[:100],
                        'url': link['href'],
                        'date': datetime.now().isoformat()
                    })
            except:
                pass
        
        print(f"✓ Found {len(listings)} listings")
        return listings
    except Exception as e:
        print(f"✗ Scrape failed: {e}")
        return []

def main():
    print("\n" + "="*60)
    print("Listings Master Database — Weekly Automation")
    print("="*60)
    
    start = datetime.now()
    
    # Scrape both sources
    bizbuy = scrape_site(BIZBUY_URL, "BizBuySell")
    time.sleep(2)
    bfs = scrape_site(BUSINESS_FOR_SALE_URL, "BusinessesForSale")
    
    total = len(bizbuy) + len(bfs)
    
    # Report
    report = f"""
Listings Master Database — Weekly Scrape
==========================================

Run: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Results:
--------
BizBuySell: {len(bizbuy)} listings added
BusinessesForSale: {len(bfs)} listings added
Total: {total} new listings

Sheet: https://docs.google.com/spreadsheets/d/{SHEET_ID}/edit

Status: ✓ Complete
Runtime: {(datetime.now() - start).seconds}s
"""
    
    print(report)
    
    # Send report email
    send_email(
        "✓ Listings Master Database — Weekly Scrape Complete",
        report
    )
    
    print("="*60)

if __name__ == "__main__":
    main()
