#!/usr/bin/env python3
"""
Listings Master Database Automation v2
- Scrapes BizBuySell + BusinessesForSale
- Clicks into each listing for full details
- Parses via Dealio GPT parser
- Deduplicates & adds to Google Sheet
- Sends email with results
"""

import os
import sys
import json
import time
import smtplib
import gspread
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request

# ============================================================================
# CONFIGURATION
# ============================================================================

SHEET_ID = "13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148"
SHEET_TAB = "listings_master"
EMAIL_TO = "touhiduliet@gmail.com"
RESEND_API_KEY = "re_9AtYyDPh_KEz5LVymAyk6bwRWGNB1upq4"
DEALIO_GPT_URL = "https://chatgpt.com/g/g-69c8554829048191bd1d0f51aa8c1c28-dealio-listing-parser"

# Google OAuth Token
OAUTH_TOKEN = {
    "token": "ya29.a0AT3oNZ-JW_7EcYKUWaIZKZdStO074Ke4ssKwy9NUiYW-7GZmcdieSHOK17ZDM2Nn-6hlOFkDhEFQ84ii9II5b40R8Lcv4I-4easnsR6HNbDDfCvrZsuqYuGRpekGrDAtMpYZkkuFYDy9mTFEiRO5531B_9DbaVg9ExiENYSiWlqmU5rQVJoBKFmeDYkn50fk1pKn65rsaCgYKAVMSARESFQHGX2Mi_6x5Y7Q6SJLMb6PBOgqJjQ0207",
    "refresh_token": "1//0gTCbf_lOFNEiCgYIARAAGBASNwF-L9IrC0-1Ei4F_RlCfukXzLQnzf4_AhB1Lotaz3hKMXZQTYqWO5r8mh1oasZJyd6RxV3Gq2A",
    "token_uri": "https://oauth2.googleapis.com/token",
    "client_id": "902478705286-ls0579voqir3hd8fue7mks9hjl0gm845.apps.googleusercontent.com",
    "client_secret": "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",
    "scopes": ["https://www.googleapis.com/auth/spreadsheets"],
    "universe_domain": "googleapis.com"
}

# ============================================================================
# UTILITIES
# ============================================================================

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

def get_sheet_client():
    """Connect to Google Sheet using OAuth token"""
    try:
        creds = Credentials.from_authorized_user_info(OAUTH_TOKEN)
        if creds.expired:
            creds.refresh(Request())
        gc = gspread.authorize(creds)
        return gc.open_by_key(SHEET_ID).worksheet(SHEET_TAB)
    except Exception as e:
        log(f"❌ Sheet connection failed: {e}")
        return None

def get_existing_urls(sheet):
    """Fetch all existing URLs from sheet to avoid duplicates"""
    try:
        rows = sheet.get_all_values()
        urls = set()
        for row in rows[1:]:  # Skip header
            if len(row) > 2:  # URL column
                urls.add(row[2].strip())
        log(f"✓ Loaded {len(urls)} existing URLs from sheet")
        return urls
    except Exception as e:
        log(f"⚠️  Could not fetch existing URLs: {e}")
        return set()

def send_email(subject, body):
    """Send email via Resend API"""
    try:
        import requests
        headers = {
            "Authorization": f"Bearer {RESEND_API_KEY}",
            "Content-Type": "application/json"
        }
        data = {
            "from": "Listings Master <onboarding@resend.dev>",
            "to": EMAIL_TO,
            "subject": subject,
            "html": body
        }
        resp = requests.post("https://api.resend.com/emails", json=data, headers=headers)
        if resp.status_code == 200:
            log(f"✓ Email sent to {EMAIL_TO}")
        else:
            log(f"⚠️  Email failed: {resp.status_code}")
    except Exception as e:
        log(f"⚠️  Email error: {e}")

# ============================================================================
# MAIN SCRAPER (PLACEHOLDER - REQUIRES HERMES BROWSER INTEGRATION)
# ============================================================================

def scrape_listings():
    """
    MAIN FUNCTION - This requires Hermes browser integration to:
    1. Navigate to BizBuySell filtered URL
    2. Extract listing links
    3. Click into each listing
    4. Copy full page content
    5. Parse via Dealio GPT
    6. Deduplicate
    7. Add to sheet
    
    For now: MOCK DATA to show structure
    """
    
    log("=" * 70)
    log("Listings Master Database Automation v2")
    log("=" * 70)
    
    sheet = get_sheet_client()
    if not sheet:
        log("❌ Cannot connect to sheet. Aborting.")
        return 0, 0
    
    existing_urls = get_existing_urls(sheet)
    
    # ========================================================================
    # MOCK DATA - Replace with real browser scraping
    # ========================================================================
    
    mock_listings = [
        {
            "source": "BizBuySell",
            "title": "Plumbing Services - Ontario",
            "price": "$450,000",
            "url": "https://www.bizbuysell.com/ontario-business-for-sale/plumbing-1234",
            "location": "Toronto, ON",
            "date_scraped": datetime.now().strftime("%Y-%m-%d")
        },
        {
            "source": "BizBuySell",
            "title": "Digital Marketing Agency",
            "price": "$350,000",
            "url": "https://www.bizbuysell.com/ontario-business-for-sale/digital-agency-5678",
            "location": "Mississauga, ON",
            "date_scraped": datetime.now().strftime("%Y-%m-%d")
        },
        {
            "source": "BusinessesForSale",
            "title": "Fitness Studio - Franchise",
            "price": "$280,000",
            "url": "https://canada.businessesforsale.com/canadian/listing-fitness-9012",
            "location": "Vancouver, BC",
            "date_scraped": datetime.now().strftime("%Y-%m-%d")
        }
    ]
    
    # ========================================================================
    # FILTER & ADD TO SHEET
    # ========================================================================
    
    bizbuy_count = 0
    bfs_count = 0
    
    for listing in mock_listings:
        if listing["url"] not in existing_urls:
            try:
                sheet.append_row([
                    listing["source"],
                    listing["title"],
                    listing["url"],
                    listing["price"],
                    listing["location"],
                    listing["date_scraped"]
                ])
                log(f"✓ Added: {listing['title']}")
                
                if listing["source"] == "BizBuySell":
                    bizbuy_count += 1
                else:
                    bfs_count += 1
                    
                time.sleep(0.5)  # Rate limit
            except Exception as e:
                log(f"⚠️  Failed to add row: {e}")
        else:
            log(f"⊘ Duplicate: {listing['url']}")
    
    log(f"\n📊 Summary:")
    log(f"   BizBuySell: {bizbuy_count} new listings")
    log(f"   BusinessesForSale: {bfs_count} new listings")
    log(f"   Total: {bizbuy_count + bfs_count} new listings")
    
    return bizbuy_count, bfs_count

# ============================================================================
# EMAIL REPORT
# ============================================================================

def send_report(bizbuy_count, bfs_count):
    """Send results email"""
    
    total = bizbuy_count + bfs_count
    status = "✓ Complete" if total > 0 else "⚠️  No new listings found"
    
    body = f"""
    <h2>Listings Master Database — Weekly Scrape</h2>
    <p><strong>Run:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    
    <h3>Results:</h3>
    <ul>
        <li><strong>BizBuySell:</strong> {bizbuy_count} listings added</li>
        <li><strong>BusinessesForSale:</strong> {bfs_count} listings added</li>
        <li><strong>Total:</strong> {total} new listings</li>
    </ul>
    
    <p><strong>Sheet:</strong> <a href="https://docs.google.com/spreadsheets/d/{SHEET_ID}/edit">Dealio_Listings_Master</a></p>
    <p><strong>Status:</strong> {status}</p>
    """
    
    send_email("Listings Master Database — Weekly Scrape", body)

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    try:
        bizbuy_count, bfs_count = scrape_listings()
        send_report(bizbuy_count, bfs_count)
        log("\n✓ Job complete")
    except Exception as e:
        log(f"\n❌ Job failed: {e}")
        send_email("❌ Listings Master Automation Failed", f"<p>Error: {e}</p>")
