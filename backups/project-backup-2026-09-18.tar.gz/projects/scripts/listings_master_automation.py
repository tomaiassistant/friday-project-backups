#!/usr/bin/env python3
"""
Listings Master Database Automation
- Scrapes BizBuySell + BusinessesForSale (last 7 days)
- Deduplicates against existing sheet
- Parses listing details via AI/LLM
- Appends new listings to Google Sheet

Usage: python3 listings_master_automation.py
Runs: Mondays 3am (via cron)
"""

import os
import sys
import json
import time
import logging
from datetime import datetime, timedelta
from urllib.parse import urljoin, urlparse
from collections import defaultdict

# Install deps if missing
try:
    import requests
    from bs4 import BeautifulSoup
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
except ImportError:
    print("Installing dependencies...")
    os.system("pip install requests beautifulsoup4 google-auth-oauthlib google-api-python-client -q")
    import requests
    from bs4 import BeautifulSoup
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build

# Logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s'
)
log = logging.getLogger(__name__)

# ==============================================================================
# CONFIG
# ==============================================================================

SHEET_ID = '13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148'
LISTINGS_MASTER_TAB = 'listings_master'

# OAuth token (hardcoded for cron, rotated via Hermes)
GOOGLE_OAUTH_TOKEN = {
    "token": "ya29.a0AT3oNZ-JW_7EcYKUhhZdStO074Ke4ssKwy9NUiYW-7GZmcdieSHOK17ZDM2Nn-6hlOFkDhEFQ84ii9II5b40R8Lcv4I-4easnsR6HNbDDfCvrZsuqYuGRpekGrDAtMpYZkkuFYDy9mTFEiRO5531B_9DbaVg9ExiENYSiWlqmU5rQVJoBKFmeDYkn50fk1pKn65rsaCgYKAVMSARESFQHGX2Mi_6x5Y7Q6SJLMb6PBOgqJjQ0207",
    "refresh_token": "1//0gTCbf_lOFNEiCgYIARAAGBASNwF-L9IrC0-1Ei4F_RlCfukXzLQnzf4_AhB1Lotaz3hKMXZQTYqWO5r8mh1oasZJyd6RxV3Gq2A",
    "token_uri": "https://oauth2.googleapis.com/token",
    "client_id": "902478705286-ls0579voqir3hd8fue7mks9hjl0gm845.apps.googleusercontent.com",
    "client_secret": "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",
    "scopes": ["https://www.googleapis.com/auth/spreadsheets"],
    "type": "authorized_user"
}

# Apify PAT (rotate for rate limits)
APIFY_PATS = [
    "apify_api_QWeSTJkvVJiKMwn1OaH6O6AQi4wAQl0yM1Ig",
    "apify_api_9boeCGv1pkontsvDSB74ge44q6UC5w2PhmRh",
    "apify_api_v3Q1GwVd5F29oC6q4xWYfZOrgzexO02bxMHV",
]

SCRAPEDO_KEYS = [
    "6efca8099deb4739bcc72f171f7641225accdaf5fd8",
    "aab9e78d6d8b4242914390c35b8efcbf147f1852501",
]

# Target URLs
BIZBUYSELL_URL = "https://www.bizbuysell.com/ontario-canada-businesses-for-sale/?q=aTI9ODgsMTM2LDE0MSw4MSw4OSwyNywyMiwxMTgsMzEsNTcsMTE1LDE4OCwxLDIwLDMwLDIwNiw3OCwyMTMmbHQ9MzAsNDAsODA%3D"
BUSINESSESFORSALE_URL = "https://canada.businessesforsale.com/canadian/search?CategoryIds=1299301&CategoryIds=1387201&CategoryIds=1316601&CategoryIds=1294601&CategoryIds=1294101&CategoryIds=1293501&CategoryIds=1389001&CategoryIds=1360201&CategoryIds=1293801&CategoryIds=1293901&CategoryIds=1293401&CategoryIds=1365401&RegionIds=1022301"

# ==============================================================================
# GOOGLE SHEETS API
# ==============================================================================

class SheetsAPI:
    def __init__(self, token_data):
        self.creds = Credentials.from_authorized_user_info(token_data)
        self.service = build('sheets', 'v4', credentials=self.creds)
    
    def get_all_urls(self, sheet_id, tab='listings_master'):
        """Get all source_url values from sheet to deduplicate"""
        try:
            result = self.service.spreadsheets().values().get(
                spreadsheetId=sheet_id,
                range=f'{tab}!G:G'  # Column G = source_url
            ).execute()
            urls = set()
            for row in result.get('values', [])[1:]:  # Skip header
                if row:
                    urls.add(row[0])
            log.info(f"Loaded {len(urls)} existing URLs from sheet")
            return urls
        except Exception as e:
            log.error(f"Failed to get URLs: {e}")
            return set()
    
    def append_rows(self, sheet_id, tab, rows):
        """Append new rows to sheet"""
        if not rows:
            log.info("No new rows to append")
            return
        
        try:
            body = {'values': rows}
            result = self.service.spreadsheets().values().append(
                spreadsheetId=sheet_id,
                range=f'{tab}!A:Z',
                valueInputOption='RAW',
                body=body
            ).execute()
            log.info(f"✓ Appended {len(rows)} new listings to sheet")
            return result
        except Exception as e:
            log.error(f"Failed to append rows: {e}")
            return None

# ==============================================================================
# WEB SCRAPING (Browser-based with Apify fallback)
# ==============================================================================

class ListingScraper:
    def __init__(self):
        self.sheets = SheetsAPI(GOOGLE_OAUTH_TOKEN)
        self.existing_urls = self.sheets.get_all_urls(SHEET_ID)
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        self.session = requests.Session()
    
    def scrape_with_browser_or_apify(self, url, site_name):
        """Try browser scraping, fallback to Apify"""
        log.info(f"Scraping {site_name}: {url[:60]}...")
        
        # Try direct request first
        try:
            resp = self.session.get(url, headers=self.headers, timeout=15)
            if resp.status_code == 200:
                log.info(f"  ✓ Direct request succeeded")
                return resp.text
        except Exception as e:
            log.debug(f"  Direct request failed: {e}")
        
        # Fallback to Apify
        log.info(f"  → Trying Apify...")
        for pat in APIFY_PATS:
            try:
                return self._scrape_with_apify(url, pat)
            except Exception as e:
                log.debug(f"    Apify account failed: {e}")
        
        log.error(f"  ✗ All scraping methods failed for {site_name}")
        return None
    
    def _scrape_with_apify(self, url, pat):
        """Use Apify Web Scraper Actor"""
        actor_id = "apify/web-scraper"
        api_url = f"https://api.apify.com/v2/acts/{actor_id}/runs"
        
        payload = {
            "startUrls": [{"url": url}],
            "useChrome": True,
            "waitUntil": "networkidle2"
        }
        
        headers = {"Authorization": f"Bearer {pat}"}
        
        # Start run
        resp = requests.post(api_url, json=payload, headers=headers, timeout=30)
        if resp.status_code != 201:
            raise Exception(f"Apify API error: {resp.status_code}")
        
        run_id = resp.json()['data']['id']
        log.info(f"    Apify run: {run_id}")
        
        # Poll for completion
        run_url = f"{api_url}/{run_id}"
        for attempt in range(60):  # 5 min timeout
            run_resp = requests.get(run_url, headers=headers, timeout=10).json()
            status = run_resp['data']['status']
            
            if status == 'SUCCEEDED':
                # Get output
                output_url = f"https://api.apify.com/v2/acts/{actor_id}/runs/{run_id}/dataset/items"
                output = requests.get(output_url, headers=headers, timeout=10).json()
                if output:
                    return output[0].get('html', '')
                break
            elif status == 'FAILED':
                raise Exception("Apify run failed")
            
            time.sleep(5)
        
        raise Exception("Apify run timeout")
    
    def extract_listing_urls(self, html, site_name):
        """Parse HTML to extract listing URLs"""
        if not html:
            return []
        
        soup = BeautifulSoup(html, 'html.parser')
        urls = []
        
        if site_name == 'BizBuySell':
            # BizBuySell listing selector
            for link in soup.find_all('a', href=True):
                href = link.get('href', '')
                if '/business-for-sale/' in href and href not in self.existing_urls:
                    full_url = urljoin('https://www.bizbuysell.com', href)
                    urls.append(full_url)
        
        elif site_name == 'BusinessesForSale':
            # BusinessesForSale listing selector
            for link in soup.find_all('a', href=True):
                href = link.get('href', '')
                if '/businesses-for-sale/' in href and href not in self.existing_urls:
                    full_url = urljoin('https://canada.businessesforsale.com', href)
                    urls.append(full_url)
        
        # Deduplicate and filter existing
        urls = list(set([u for u in urls if u not in self.existing_urls]))
        log.info(f"  Found {len(urls)} new listing URLs")
        return urls
    
    def get_listing_details(self, url):
        """Fetch full listing page + extract key fields"""
        try:
            resp = self.session.get(url, headers=self.headers, timeout=15)
            if resp.status_code != 200:
                return None
            
            soup = BeautifulSoup(resp.text, 'html.parser')
            
            # Extract common fields (varies by site)
            detail = {
                'source_url': url,
                'source_site': 'BizBuySell' if 'bizbuysell' in url else 'BusinessesForSale',
                'listing_title': None,
                'company_name': None,
                'asking_price': None,
                'revenue': None,
                'city': None,
                'state_province': None,
                'industry': None,
            }
            
            # Attempt to extract via common selectors
            # (This is heuristic — real parsing may need per-site logic)
            title = soup.find('h1') or soup.find('title')
            if title:
                detail['listing_title'] = title.get_text(strip=True)[:200]
            
            # Price patterns
            for text in soup.find_all(string=True):
                text = text.strip()
                if '$' in text and any(word in text.lower() for word in ['asking', 'price', 'cost']):
                    detail['asking_price'] = text[:100]
                    break
            
            return detail
        
        except Exception as e:
            log.debug(f"Error fetching details for {url}: {e}")
            return None
    
    def build_sheet_row(self, detail):
        """Convert detail dict to Google Sheet row (26 columns)"""
        cols = [
            None,  # Publish
            None,  # listing_id
            datetime.now().isoformat(),  # created_at
            datetime.now().isoformat(),  # updated_at
            1,  # is_active
            detail.get('source_site', 'Unknown'),  # source_site
            detail.get('source_url', ''),  # source_url
            detail.get('source_url', '').split('/')[-1][:50],  # source_listing_key
            None,  # listed_by
            detail.get('listing_title', 'N/A'),  # listing_title
            detail.get('company_name', 'N/A'),  # company_name
            detail.get('industry', 'N/A'),  # industry
            'N/A',  # sub_industry
            'N/A',  # industry_normalized
            'N/A',  # keywords_normalized
            detail.get('city', 'N/A'),  # city
            'N/A',  # region
            detail.get('state_province', 'Canada'),  # state_province
            'Canada',  # country
            'N/A',  # geo_normalized
            detail.get('asking_price', 'N/A'),  # asking_price
            detail.get('revenue', 'N/A'),  # revenue
            'N/A',  # ebitda
            'N/A',  # sde_cash_flow
            0,  # financials_disclosed
            0,  # revenue_disclosed
        ]
        return cols
    
    def run(self):
        """Main scraper workflow"""
        log.info("=" * 80)
        log.info("Listings Master Database Automation")
        log.info("=" * 80)
        
        all_new_rows = []
        
        # Scrape BizBuySell
        html = self.scrape_with_browser_or_apify(BIZBUYSELL_URL, 'BizBuySell')
        if html:
            urls = self.extract_listing_urls(html, 'BizBuySell')
            for url in urls[:20]:  # Limit to 20 per run
                detail = self.get_listing_details(url)
                if detail:
                    row = self.build_sheet_row(detail)
                    all_new_rows.append(row)
                    self.existing_urls.add(url)
                    log.info(f"  + {detail.get('listing_title', 'Unknown')[:50]}")
                time.sleep(1)  # Rate limit
        
        # Scrape BusinessesForSale
        html = self.scrape_with_browser_or_apify(BUSINESSESFORSALE_URL, 'BusinessesForSale')
        if html:
            urls = self.extract_listing_urls(html, 'BusinessesForSale')
            for url in urls[:20]:  # Limit to 20 per run
                detail = self.get_listing_details(url)
                if detail:
                    row = self.build_sheet_row(detail)
                    all_new_rows.append(row)
                    self.existing_urls.add(url)
                    log.info(f"  + {detail.get('listing_title', 'Unknown')[:50]}")
                time.sleep(1)  # Rate limit
        
        # Append to sheet
        if all_new_rows:
            self.sheets.append_rows(SHEET_ID, LISTINGS_MASTER_TAB, all_new_rows)
        
        log.info("=" * 80)
        log.info(f"✓ Complete. Added {len(all_new_rows)} new listings.")
        log.info("=" * 80)
        
        return len(all_new_rows)

# ==============================================================================
# MAIN
# ==============================================================================

if __name__ == '__main__':
    scraper = ListingScraper()
    try:
        count = scraper.run()
        sys.exit(0)
    except Exception as e:
        log.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)
