#!/usr/bin/env python3
import json
import os
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path

ENV_PATH = Path('/root/.hermes/.env')
STATE_PATH = Path('/root/.hermes/state/tmcp_unread_email_seen.json')
BASE_URL_DEFAULT = 'https://tmcp.vercel.app/api/gateway'
GMAIL_ACCOUNT_ID = '32354c21-a100-4794-86cb-3e1365e7265b'  # Gmail (touhiduliet@gmail.com)

MARKETING_WORDS = re.compile(
    r'(unsubscribe|newsletter|promotion|promo|sale|discount|offer|deal|coupon|ad approved|marketing|campaign|webinar|limited time|% off)',
    re.I,
)
MARKETING_SENDERS = re.compile(
    r'(noreply|no-reply|newsletter|marketing|promo|offers|mailchimp|sendgrid|hubspot|meta for business)',
    re.I,
)


def load_env():
    values = {}
    if ENV_PATH.exists():
        for line in ENV_PATH.read_text().splitlines():
            if '=' in line and not line.lstrip().startswith('#'):
                key, value = line.split('=', 1)
                values[key.strip()] = value.strip()
    return values


def tmcp_call(api_key, base_url, action, input_data):
    body = {
        'tool': 'gmail',
        'action': action,
        'account_id': GMAIL_ACCOUNT_ID,
        'input': input_data,
    }
    req = urllib.request.Request(
        base_url.rstrip('/') + '/execute',
        data=json.dumps(body).encode(),
        method='POST',
        headers={
            'Authorization': 'Bearer ' + api_key,
            'Content-Type': 'application/json',
            'User-Agent': 'Hermes-Friday-email-watch/1.0',
        },
    )
    with urllib.request.urlopen(req, timeout=45) as resp:
        data = json.loads(resp.read().decode() or '{}')
    if not data.get('success'):
        raise RuntimeError(data.get('error') or data.get('message') or 'TMCP call failed')
    return data.get('result') or {}


def header(headers, name):
    for h in headers or []:
        if str(h.get('name', '')).lower() == name.lower():
            return h.get('value', '')
    return ''


def is_marketing(msg):
    subject = header(msg.get('payload', {}).get('headers', []), 'Subject') or msg.get('subject', '')
    sender = header(msg.get('payload', {}).get('headers', []), 'From') or msg.get('from', '')
    snippet = msg.get('snippet', '') or ''
    text = f'{sender}\n{subject}\n{snippet}'
    return bool(MARKETING_SENDERS.search(sender) or MARKETING_WORDS.search(text))


def main():
    env = load_env()
    api_key = env.get('TMCP_API_KEY') or os.environ.get('TMCP_API_KEY')
    base_url = env.get('TMCP_BASE_URL') or os.environ.get('TMCP_BASE_URL') or BASE_URL_DEFAULT
    if not api_key:
        print('Email watch error: TMCP_API_KEY not configured')
        return 1

    # Gmail categories remove common promotions/social. `newer_than:2h` catches delays without reporting old backlog forever.
    query = 'to:touhiduliet@gmail.com is:unread newer_than:2h -category:promotions -category:social'
    result = tmcp_call(api_key, base_url, 'gmail.search', {'query': query})
    messages = result.get('messages') or []
    if not messages:
        return 0

    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        seen = set(json.loads(STATE_PATH.read_text()).get('seen_ids', []))
    except Exception:
        seen = set()

    alerts = []
    for item in messages[:10]:
        msg_id = item.get('id')
        if not msg_id or msg_id in seen:
            continue
        try:
            msg = tmcp_call(api_key, base_url, 'gmail.read', {'id': msg_id})
        except Exception:
            msg = item
        seen.add(msg_id)
        if is_marketing(msg):
            continue
        headers = msg.get('payload', {}).get('headers', [])
        subject = header(headers, 'Subject') or msg.get('subject', '(No subject)')
        sender = header(headers, 'From') or msg.get('from', 'Unknown sender')
        snippet = (msg.get('snippet') or '').replace('\n', ' ').strip()
        alerts.append(f'- From: {sender}\n  Subject: {subject}' + (f'\n  Preview: {snippet[:180]}' if snippet else ''))

    STATE_PATH.write_text(json.dumps({'seen_ids': list(seen)[-500:]}, indent=2))

    if alerts:
        print('Sir, you have new unread non-marketing email(s) in touhiduliet@gmail.com:\n' + '\n'.join(alerts))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f'Email watch error: {exc}')
        raise SystemExit(1)
