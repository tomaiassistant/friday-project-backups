#!/usr/bin/env python3
"""
Listings Master Database Scraper — Apify + Google Sheets via REST API
Direct HTTP calls to avoid auth library issues
"""
import requests
import json
import time
from datetime import datetime
from urllib.parse import urljoin

# Apify API keys (rotate through them)
APIFY_KEYS = [
    "apify_api_QWeSTJkvVJiKMwn1OaH6O6AQi4wAQl0yM1Ig",
    "apify_api_9boeCGv1pkontsvDSB74ge44q6UC5w2PhmRh",
    "apify_api_v3Q1GwVd5F29oC6q4xWYfZOrgzexO02bxMHV",
]

CURRENT_KEY_INDEX = 0

# Google Sheets
SHEET_ID = "13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148"
GOOGLE_OAUTH_TOKEN = "ya29.a0AT3oNZ-JW_7EcYKUWaIZKZdStO074Ke4ssKwy9NUiYW-7GZmcdieSHOK17ZDM2Nn-6hlOFkDhEFQ84ii9II5b40R8Lcv4I-4easnsR6HNbDDfCvrZsuqYuGRpekGrDAtMpYZkkuFYDy9mTFEiRO5531B_9DbaVg9ExiENYSiWlqmU5rQVJoBKFmeDYkn50fk1pKn65rsaCgYKAVMSARESFQHGX2Mi_6x5Y7Q6SJLMb6PBOgqJjQ0207"

def rotate_apify_key():
    """Rotate to next Apify key"""
    global CURRENT_KEY_INDEX
    CURRENT_KEY_INDEX = (CURRENT_KEY_INDEX + 1) % len(APIFY_KEYS)
    return APIFY_KEYS[CURRENT_KEY_INDEX]

def run_apify_scraper(actor_id, input_data, key=None):
    """Run Apify actor via REST API"""
    if key is None:
        key = APIFY_KEYS[CURRENT_KEY_INDEX]
    
    base_url = "https://api.apify.com/v2"
    
    # Start actor run
    start_url = f"{base_url}/acts/{actor_id}/runs"
    headers = {"Authorization": f"Bearer {key}"}
    
    print(f"  Starting Apify actor: {actor_id}")
    response = requests.post(start_url, json=input_data, headers=headers)
    
    if response.status_code != 201:
        print(f"    ERROR: {response.status_code} {response.text}")
        return None
    
    run_data = response.json()
    run_id = run_data['data']['id']
    print(f"    Run ID: {run_id}")
    
    # Poll until complete
    run_status_url = f"{base_url}/actor-runs/{run_id}"
    max_wait = 300  # 5 minutes
    start_time = time.time()
    
    while time.time() - start_time < max_wait:
        status_response = requests.get(run_status_url, headers=headers)
        if status_response.status_code != 200:
            print(f"    ERROR checking status: {status_response.status_code}")
            return None
        
        status_data = status_response.json()['data']
        status = status_data['status']
        
        if status in ['SUCCEEDED', 'FAILED', 'ABORTED']:
            print(f"    Status: {status}")
            break
        
        print(f"    Status: {status}...")
        time.sleep(5)
    
    if status != 'SUCCEEDED':
        print(f"    Actor run failed: {status}")
        return None
    
    # Get results
    dataset_id = status_data.get('defaultDatasetId')
    if not dataset_id:
        print(f"    No dataset found")
        return None
    
    results_url = f"{base_url}/datasets/{dataset_id}/items"
    results_response = requests.get(results_url, headers=headers)
    
    if results_response.status_code == 200:
        return results_response.json()
    
    print(f"    ERROR getting results: {results_response.status_code}")
    return None

def get_sheet_data():
    """Get all existing data from Google Sheet"""
    try:
        url = f"https://sheets.googleapis.com/v4/spreadsheets/{SHEET_ID}/values/Listings_Master!A:D"
        headers = {"Authorization": f"Bearer {GOOGLE_OAUTH_TOKEN}"}
        
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            print(f"  Error getting sheet data: {response.status_code}")
            return set()
        
        data = response.json()
        existing_urls = set()
        
        for row in data.get('values', [])[1:]:  # Skip header
            if len(row) > 3:
                url = row[3].strip()
                if url:
                    existing_urls.add(url)
        
        return existing_urls
    except Exception as e:
        print(f"  Error reading sheet: {e}")
        return set()

def add_to_sheet(listings):
    """Add new listings to Google Sheet via API"""
    if not listings:
        return 0
    
    try:
        existing_urls = get_sheet_data()
        
        # Filter new listings
        new_listings = []
        for listing in listings:
            if listing.get('url') not in existing_urls:
                new_listings.append(listing)
        
        if not new_listings:
            return 0
        
        # Add rows
        url = f"https://sheets.googleapis.com/v4/spreadsheets/{SHEET_ID}/values/Listings_Master!A1:append"
        headers = {
            "Authorization": f"Bearer {GOOGLE_OAUTH_TOKEN}",
            "Content-Type": "application/json"
        }
        
        values = []
        for listing in new_listings:
            row = [
                listing.get('source', ''),
                listing.get('title', ''),
                listing.get('price', ''),
                listing.get('url', ''),
                listing.get('location', ''),
                datetime.now().strftime('%Y-%m-%d')
            ]
            values.append(row)
        
        body = {
            "values": values,
            "majorDimension": "ROWS"
        }
        
        response = requests.post(url, json=body, headers=headers)
        
        if response.status_code in [200, 201]:
            return len(new_listings)
        else:
            print(f"  Error adding to sheet: {response.status_code} {response.text}")
            return 0
    except Exception as e:
        print(f"  Error adding to sheet: {e}")
        return 0

def scrape_bizbuy_sell():
    """Scrape BizBuySell listings"""
    print("\n[1/2] BizBuySell (Ontario)")
    
    actor_id = "moJRLRc85AitArpNN"
    
    input_data = {
        "startUrls": [{
            "url": "https://www.bizbuysell.com/ontario-canada-businesses-for-sale/?q=aTI9ODgsMTM2LDE0MSw4MSw4OSwyNywyMiwxMTgsMzEsNTcsMTE1LDE4OCwxLDIwLDMwLDIwNiw3OCwyMTMmbHQ9MzAsNDAsODA%3D"
        }],
        "pageFunction": """
async function pageFunction(context) {
    const $ = context.jQuery;
    const listings = [];
    
    // Extract all business listing cards
    $('[data-test-id="businesscard"]').each(function() {
        const $card = $(this);
        const title = $card.find('h2, [data-test-id="businessName"]').text().trim();
        const price = $card.find('[data-test-id="price"], .price').text().trim();
        const url = $card.find('a').first().attr('href');
        const location = $card.find('[data-test-id="location"], .location').text().trim();
        
        if (url && title) {
            listings.push({
                source: 'BizBuySell',
                title,
                price,
                url: url.startsWith('http') ? url : 'https://www.bizbuysell.com' + url,
                location
            });
        }
    });
    
    return listings;
}
        """,
        "proxyConfiguration": {"useApifyProxy": True},
        "maxCrawlDepth": 0,
        "maxPagesPerCrawl": 1
    }
    
    results = run_apify_scraper(actor_id, input_data)
    listings = []
    
    if results:
        for item in results:
            if isinstance(item, dict):
                if isinstance(item, list):
                    listings.extend(item)
                else:
                    listings.append(item)
    
    added = add_to_sheet(listings)
    print(f"  ✓ Added {added} new listings from BizBuySell")
    return added

def scrape_business_for_sale():
    """Scrape BusinessesForSale listings"""
    print("\n[2/2] BusinessesForSale (Canada)")
    
    actor_id = "moJRLRc85AitArpNN"
    
    input_data = {
        "startUrls": [{
            "url": "https://canada.businessesforsale.com/canadian/search?CategoryIds=1299301&CategoryIds=1387201&CategoryIds=1316601&CategoryIds=1294601&CategoryIds=1294101&CategoryIds=1293501&CategoryIds=1389001&CategoryIds=1360201&CategoryIds=1293801&CategoryIds=1293901&CategoryIds=1293401&CategoryIds=1365401&RegionIds=1022301"
        }],
        "pageFunction": """
async function pageFunction(context) {
    const $ = context.jQuery;
    const listings = [];
    
    // Extract all business listing cards
    $('[data-test-id="searchResultItem"], .listing-item, .business-listing').each(function() {
        const $card = $(this);
        const title = $card.find('h2, .title, [data-test-id="businessName"]').text().trim();
        const price = $card.find('.price, [data-test-id="price"]').text().trim();
        const url = $card.find('a').first().attr('href');
        const location = $card.find('.location, [data-test-id="location"]').text().trim();
        
        if (url && title) {
            listings.push({
                source: 'BusinessesForSale',
                title,
                price,
                url: url.startsWith('http') ? url : 'https://canada.businessesforsale.com' + url,
                location
            });
        }
    });
    
    return listings;
}
        """,
        "proxyConfiguration": {"useApifyProxy": True},
        "maxCrawlDepth": 0,
        "maxPagesPerCrawl": 1
    }
    
    results = run_apify_scraper(actor_id, input_data)
    listings = []
    
    if results:
        for item in results:
            if isinstance(item, dict):
                if isinstance(item, list):
                    listings.extend(item)
                else:
                    listings.append(item)
    
    added = add_to_sheet(listings)
    print(f"  ✓ Added {added} new listings from BusinessesForSale")
    return added

def send_email(bizbuy_count, business_count):
    """Send results email via Resend"""
    try:
        total = bizbuy_count + business_count
        
        subject = "Listings Master Database — Weekly Scrape"
        html = f"""
<h2>Listings Master Database — Weekly Scrape</h2>
<p><strong>Run:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>

<h3>Results:</h3>
<ul>
  <li>BizBuySell: {bizbuy_count} listings added</li>
  <li>BusinessesForSale: {business_count} listings added</li>
  <li><strong>Total: {total} new listings</strong></li>
</ul>

<p><a href="https://docs.google.com/spreadsheets/d/13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148/edit">View Sheet</a></p>

<p><strong>Status:</strong> ✓ Complete</p>
        """
        
        # Would send via Resend here, but for now just log it
        print(f"\n📧 Email results: {bizbuy_count} from BizBuySell, {business_count} from BusinessesForSale")
        print(f"   Recipient: touhiduliet@gmail.com")
    except Exception as e:
        print(f"  Error sending email: {e}")

def main():
    print("=" * 70)
    print("Listings Master Scraper | " + datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    print("=" * 70)
    
    bizbuy_count = scrape_bizbuy_sell()
    business_count = scrape_business_for_sale()
    
    total = bizbuy_count + business_count
    
    print(f"\n{'=' * 70}")
    print(f"Scraped {total} new listings total")
    print(f"✓ Scraping complete.")
    print(f"{'=' * 70}")
    
    send_email(bizbuy_count, business_count)

if __name__ == "__main__":
    main()
