#!/usr/bin/env python3
"""
Listings Master Database - WORKING SOLUTION
Direct extraction from BizBuySell using hermes browser CLI tool
"""

import subprocess
import json
import time
import gspread
from datetime import datetime
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials

GOOGLE_OAUTH_TOKEN = {
    "token": "ya29.a0AT3oNZ-JW_7EcYKUWaIZKZdStO074Ke4ssKwy9NUiYW-7GZmcdieSHOK17ZDM2Nn-6hlOFkDhEFQ84ii9II5b40R8Lcv4I-4easnsR6HNbDDfCvrZsuqYuGRpekGrDAtMpYZkkuFYDy9mTFEiRO5531B_9DbaVg9ExiENYSiWlqmU5rQVJoBKFmeDYkn50fk1pKn65rsaCgYKAVMSARESFQHGX2Mi_6x5Y7Q6SJLMb6PBOgqJjQ0207",
    "refresh_token": "1//0gTCbf_lOFNEiCgYIARAAGBASNwF-L9IrC0-1Ei4F_RlCfukXzLQnzf4_AhB1Lotaz3hKMXZQTYqWO5r8mh1oasZJyd6RxV3Gq2A",
    "token_uri": "https://oauth2.googleapis.com/token",
    "client_id": "902478705286-ls0579voqir3hd8fue7mks9hjl0gm845.apps.googleusercontent.com",
    "client_secret": "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",
    "type": "authorized_user"
}

SHEET_ID = "13H7Ig3eU14bYOSV7Z4L5Tv0C7PndXB1PQgQmFSM0148"
TARGET_SHEET = "listings_master"

def extract_listings_via_hermes_cli():
    """Use hermes CLI browser to extract listings"""
    
    url = "https://www.bizbuysell.com/ontario-canada-businesses-for-sale/?q=aTI9ODgsMTM2LDE0MSw4MSw4OSwyNywyMiwxMTgsMzEsNTcsMTE1LDE4OCwxLDIwLDMwLDIwNiw3OCwyMTMmbHQ9MzAsNDAsODA%3D"
    
    print(f"[*] Loading BizBuySell via Hermes browser...")
    
    # Use hermes browser navigate and extract
    script = f"""
import subprocess
import json

# Call hermes browser to navigate
result = subprocess.run([
    "hermes", "browser-navigate",
    "--url", "{url}"
], capture_output=True, text=True, timeout=60)

# Extract listing links
result2 = subprocess.run([
    "hermes", "browser-console",
    "--expression", '''
const listings = [];
const links = document.querySelectorAll('a[href*="/view/"]');
links.forEach(link => {{
  const text = link.innerText.trim();
  const href = link.getAttribute("href");
  if (text && text.length > 10 && href && href.includes("/view/")) {{
    listings.push({{
      title: text.substring(0, 200),
      url: href,
      source: "BizBuySell"
    }});
  }}
}});
JSON.stringify(listings.slice(0, 100));
'''
], capture_output=True, text=True, timeout=30)

print(result2.stdout)
"""
    
    try:
        proc = subprocess.run([
            "hermes", "browser-navigate",
            "--url", url
        ], capture_output=True, text=True, timeout=120)
        
        print(f"  Browser loaded ✓")
        
        # Now extract with console
        extract_code = """
const listings = [];
const links = document.querySelectorAll('a[href*="/view/"]');
links.forEach(link => {
  const text = link.innerText.trim();
  const href = link.getAttribute("href");
  if (text && text.length > 10 && href && href.includes("/view/")) {
    listings.push({
      title: text.substring(0, 200),
      url: href
    });
  }
});
JSON.stringify(listings.slice(0, 50));
"""
        
        proc = subprocess.run([
            "hermes", "browser-console",
            "--expression", extract_code
        ], capture_output=True, text=True, timeout=60)
        
        print(f"  Console response: {proc.stdout[:200]}")
        
        if proc.returncode == 0:
            try:
                listings = json.loads(proc.stdout)
                print(f"  ✓ Extracted {len(listings)} listings")
                return listings
            except:
                pass
        
        return []
    
    except Exception as e:
        print(f"  Error: {e}")
        return []

def get_existing_urls():
    """Load existing URLs from sheet"""
    try:
        creds = Credentials.from_authorized_user_info(GOOGLE_OAUTH_TOKEN)
        creds.refresh(Request())
        gc = gspread.authorize(creds)
        
        ws = gc.open_by_key(SHEET_ID).worksheet(TARGET_SHEET)
        rows = ws.get_all_values()
        
        urls = set()
        for row in rows[1:]:
            if len(row) > 6 and row[6]:
                urls.add(row[6].strip())
        
        print(f"✓ Loaded {len(urls)} existing URLs")
        return urls
    except Exception as e:
        print(f"Error: {e}")
        return set()

def add_to_sheet(listings):
    """Add listings to sheet with correct format"""
    if not listings:
        return 0
    
    try:
        creds = Credentials.from_authorized_user_info(GOOGLE_OAUTH_TOKEN)
        creds.refresh(Request())
        gc = gspread.authorize(creds)
        
        ws = gc.open_by_key(SHEET_ID).worksheet(TARGET_SHEET)
        
        rows = []
        for l in listings:
            listing_id = l.get("url", "").split("/")[-2][:20] if l.get("url") else "unknown"
            
            row = [
                "FALSE",                          # Publish
                listing_id,                       # listing_id
                datetime.now().isoformat() + "Z", # created_at
                "N/A",                            # updated_at
                "TRUE",                           # is_active
                "BizBuySell",                     # source_site
                l.get("url", ""),                 # source_url
                listing_id,                       # source_listing_key
                "",                               # listed_by
                l.get("title", "")[:200],         # listing_title
                "",                               # company_name (10)
                "",                               # industry (11)
                "",                               # sub_industry (12)
                "",                               # industry_normalized (13)
                "",                               # keywords_normalized (14)
                "",                               # city (15)
                "",                               # region (16)
                "Ontario",                        # state_province (17)
                "Canada",                         # country (18)
                "Ontario, Canada",                # geo_normalized (19)
                "",                               # asking_price (20)
                "",                               # revenue (21)
                "",                               # ebitda (22)
                "",                               # sde_cash_flow (23)
                "FALSE",                          # financials_disclosed (24)
                "FALSE",                          # revenue_disclosed (25)
                "FALSE",                          # ebitda_disclosed (26)
                "",                               # employees (27)
                "",                               # established_year (28)
                "",                               # property_type (29)
                "",                               # is_work_from_home (30)
                "",                               # is_franchise (31)
                "",                               # is_business_opportunity (32)
                "",                               # is_low_cost (33)
                "",                               # is_distressed (34)
                "",                               # is_price_reduced (35)
                "",                               # is_owner_financed (36)
                "",                               # is_hidden_gem (37)
                "",                               # is_quick_sale (38)
                "",                               # management_type (39)
                datetime.now().strftime("%Y-%m-%d"),  # listing_date (40)
                "",                               # days_on_market (41)
                "",                               # listing_age_bucket (42)
                "",                               # summary (43)
                "",                               # deal_tags (44)
                "Active",                         # listing_status (45)
                "",                               # listing_dedupe_key (46)
                "",                               # manual_review_flag (47)
                "",                               # deal_summary (48)
                "",                               # dealio_id (49)
            ]
            rows.append(row)
        
        if rows:
            ws.append_rows(rows)
            print(f"✓ Added {len(rows)} rows to sheet")
            return len(rows)
        
        return 0
    except Exception as e:
        print(f"Error adding rows: {e}")
        return 0

def main():
    print("\n" + "=" * 70)
    print("Listings Master Database - WORKING VERSION")
    print(f"Run: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    
    # Extract listings
    listings = extract_listings_via_hermes_cli()
    
    if not listings:
        print("⚠️  No listings extracted")
        return
    
    print(f"\n✓ Extracted {len(listings)} listings")
    
    # Get existing URLs
    existing_urls = get_existing_urls()
    
    # Filter new ones
    new_listings = [l for l in listings if l.get("url") not in existing_urls]
    print(f"✓ {len(new_listings)} are new")
    
    # Add to sheet
    if new_listings:
        added = add_to_sheet(new_listings)
        print(f"\n✓ Complete: {added} new listings added to sheet")
    else:
        print("✓ All listings already in sheet")

if __name__ == "__main__":
    main()
