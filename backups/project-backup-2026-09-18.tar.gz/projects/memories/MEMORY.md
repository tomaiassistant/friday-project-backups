User plans to use a custom-made MCP server called TMCP to share tool access.
§
TMCP Gateway is configured in /root/.hermes/.env with TMCP_API_KEY and TMCP_BASE_URL=https://tmcp.vercel.app/api/gateway.
§
Brain Model approach: architecture-first digital brain using existing models plus local memory, reasoning, safe routing, task queue, reflection/writeback, and provider-advisory boundaries; high-risk actions require confirmation.
§
AI Knowledge repo: /root/projects/brain-model. Formerly Brain Model; now Obsidian-style MD vault to feed/ground agents. Always preserve structure + backlinks/[[Wiki Links]] between tasks, decisions, memory, specs, docs, research, and reusable skills. Verify with `. .venv/bin/activate && python -m pytest -q`.
§
Backups: Brain Model repo at /root/projects/brain-model pushes daily 08:00 Asia/Dhaka. Private GitHub repo tomaiassistant/friday-project-backups stores daily project tarballs and Hermes .hermes backup release assets via scripts in /root/.hermes/scripts/.
§
ListingsFinder is now being integrated as part of the Hermes project via skill + MCP tooling, with TMCP-backed automation rather than as a separate standalone app.
§
ListingsFinder AI repo lives at /root/projects/ListingsFinder-AI; it is a Streamlit app with a separate scheduler, and the local smoke-check command is `./.venv/bin/streamlit run app.py --server.headless true --server.port 8501 --server.address 127.0.0.1`.
§
VPS 79.108.225.121: n8n (5678), aapanel (8888), Hermes web (3000). Disk: 20GB, 86% used. Weekly cron cleanup Sun 2am. n8n SQLite VACUUM when full. Hermes web node:5173→nginx:3000 vhost `/www/server/panel/vhost/nginx/hermes.conf`.
§
Agent's role for TMCP: User of the system, not a collaborator. Operates as an agent *using* TMCP, not building it.
§
User expects summary/parsed information, not raw IDs or verbose output. Prefer sender/subject for emails over raw IDs.
§
User is frustrated by agent 'forgetting' or 'acting like a stranger' despite having access to memory and VPS. Expects agent to proactively leverage all available context.
§
migration VPS server migration - user says migrated to new server