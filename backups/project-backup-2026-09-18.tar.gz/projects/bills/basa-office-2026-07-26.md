# Basa + Office Bills — July 26, 2026

## Home
- Basa vara: 6,500/-
- Current Bill: 548/-
- Pani Bill: 200/-
- Moyla: 50/-
- **Subtotal: 7,298/-**

## Office
- Basa vara: 4,000/-
- Current Bill: 848/-
- Pani Bill: 100/-
- **Subtotal: 4,948/-**

## Combined
- Basa vara: 10,500/-
- Current Bill: 1,396/-
- Pani Bill: 300/-
- Moyla: 50/-
- **Subtotal: 12,246/-**
- Net Bill (both): 600/-
- **Total: 12,846/-**